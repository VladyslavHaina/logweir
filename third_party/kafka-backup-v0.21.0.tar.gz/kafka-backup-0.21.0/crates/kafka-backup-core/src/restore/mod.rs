//! Restore engine module.

pub mod engine;
pub mod filter;
pub(crate) mod helpers;
pub mod offset_automation;
pub mod offset_reset;
pub mod offset_rollback;
pub mod preflight;
pub mod repartition;
pub mod three_phase;

pub use engine::{RestoreEngine, RestoreProgress};
pub use filter::{FilterAction, RecordFilter, RecordFilterHandle};
pub use offset_automation::{
    BulkOffsetReset, BulkOffsetResetConfig, BulkOffsetResetReport, BulkResetStatus,
    GroupResetOutcome, OffsetMapping as BulkOffsetMapping, OffsetResetBatch, OffsetResetMetrics,
    PartitionError, PerformanceStats,
};
pub use offset_reset::{
    GroupResetPlan, GroupResetResult, OffsetResetExecutor, OffsetResetPlan, OffsetResetPlanBuilder,
    OffsetResetReport, OffsetResetStrategy, PartitionResetPlan,
};
pub use offset_rollback::{
    reset_offsets_with_rollback, rollback_offset_reset, snapshot_current_offsets, verify_rollback,
    GroupOffsetState, OffsetMismatch, OffsetSnapshot, OffsetSnapshotMetadata,
    OffsetSnapshotStorage, PartitionOffsetState, RestoreWithRollbackResult,
    RestoreWithRollbackStatus, RollbackResult, RollbackStatus, StorageBackendSnapshotStore,
    VerificationResult,
};
pub use preflight::{
    HeaderPreflightReport, PartitionCoverageState, PartitionHeaderCoverage, SnapshotCheck,
};
pub use three_phase::{OffsetResetPhaseOutcome, ThreePhaseReport, ThreePhaseRestore};
