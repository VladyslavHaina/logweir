//! Kafka client for protocol-level communication.

use bytes::{BufMut, Bytes, BytesMut};
use kafka_protocol::messages::{ApiKey, RequestHeader, ResponseHeader};
use kafka_protocol::protocol::StrBytes;
use kafka_protocol::protocol::{Decodable, Encodable};
use socket2::{SockRef, TcpKeepalive};
use std::collections::HashMap;
use std::sync::atomic::{AtomicI32, Ordering};
use std::sync::Arc;
use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpStream;
use tokio::sync::Mutex;
use tokio::time::timeout;
use tokio_rustls::rustls::pki_types::ServerName;
use tokio_rustls::TlsConnector;
use tracing::{debug, trace, warn};

/// Client-side deadline for writing a request to the broker socket.
/// If the broker's receive buffer is full for this long, something is wrong.
pub const WRITE_TIMEOUT_SECS: u64 = 10;

/// Client-side deadline for receiving a broker response.
/// Restore produces default to acks=all with a 30s broker-side timeout, so this
/// must stay above that ceiling or slow replicated writes are misclassified as
/// connection failures while the broker may still be processing the request.
pub const RESPONSE_TIMEOUT_SECS: u64 = 60;

use crate::config::{KafkaConfig, SaslMechanism, SecurityProtocol};
use crate::error::KafkaError;
use crate::Result;

use super::connection_error::{connection_io_error, request_timeout_error};
use super::metadata::{BrokerMetadata, TopicMetadata};
use super::FetchResponse;
use super::ProduceResponse;

/// Kafka client for protocol-level operations
pub struct KafkaClient {
    /// Configuration
    config: KafkaConfig,

    /// Connection to the current broker
    pub(super) connection: Arc<Mutex<Option<BrokerConnection>>>,

    /// Broker metadata cache
    brokers: Arc<Mutex<HashMap<i32, BrokerMetadata>>>,

    /// Topic metadata cache
    #[allow(dead_code)]
    topics: Arc<Mutex<HashMap<String, TopicMetadata>>>,

    /// Correlation ID counter. `Arc` so the KIP-368 re-auth scheduler task
    /// (spawned from `sasl_plugin_auth`) can share the same monotonic
    /// counter as the main client.
    pub(super) correlation_id: Arc<AtomicI32>,
}

/// A stream that can be either plain TCP or TLS-wrapped
pub(super) enum ConnectionStream {
    Plain(TcpStream),
    Tls(Box<tokio_rustls::client::TlsStream<TcpStream>>),
}

impl ConnectionStream {
    pub(super) async fn read_exact(&mut self, buf: &mut [u8]) -> std::io::Result<()> {
        match self {
            ConnectionStream::Plain(s) => {
                s.read_exact(buf).await?;
                Ok(())
            }
            ConnectionStream::Tls(s) => {
                s.read_exact(buf).await?;
                Ok(())
            }
        }
    }

    pub(super) async fn write_all(&mut self, buf: &[u8]) -> std::io::Result<()> {
        match self {
            ConnectionStream::Plain(s) => s.write_all(buf).await,
            ConnectionStream::Tls(s) => s.write_all(buf).await,
        }
    }
}

pub(super) struct BrokerConnection {
    pub(super) stream: ConnectionStream,
    #[allow(dead_code)]
    pub(super) broker_id: i32,
}

impl KafkaClient {
    /// Create a new Kafka client
    pub fn new(config: KafkaConfig) -> Self {
        Self {
            config,
            connection: Arc::new(Mutex::new(None)),
            brokers: Arc::new(Mutex::new(HashMap::new())),
            topics: Arc::new(Mutex::new(HashMap::new())),
            correlation_id: Arc::new(AtomicI32::new(1)),
        }
    }

    pub(super) fn config_clone(&self) -> KafkaConfig {
        self.config.clone()
    }

    /// Connect to the Kafka cluster
    pub async fn connect(&self) -> Result<()> {
        // Try each bootstrap server until one connects
        for server in &self.config.bootstrap_servers {
            match self.try_connect(server).await {
                Ok(stream) => {
                    let mut conn = self.connection.lock().await;
                    *conn = Some(BrokerConnection {
                        stream,
                        broker_id: -1, // Unknown until metadata fetch
                    });

                    // Perform SASL authentication if configured
                    if self.config.security.security_protocol == SecurityProtocol::SaslPlaintext
                        || self.config.security.security_protocol == SecurityProtocol::SaslSsl
                    {
                        drop(conn);
                        self.authenticate(server).await?;
                    }

                    debug!("Connected to Kafka broker: {}", server);
                    return Ok(());
                }
                Err(e) => {
                    debug!("Failed to connect to {}: {}", server, e);
                    continue;
                }
            }
        }

        Err(KafkaError::NoBrokersAvailable.into())
    }

    async fn try_connect(&self, server: &str) -> Result<ConnectionStream> {
        let tcp_stream =
            TcpStream::connect(server)
                .await
                .map_err(|e| KafkaError::ConnectionFailed {
                    broker: server.to_string(),
                    message: e.to_string(),
                })?;

        // Configure TCP socket options (keepalive, nodelay)
        self.configure_socket(&tcp_stream, server)?;

        // Wrap in TLS if using SSL or SASL_SSL
        let use_tls = matches!(
            self.config.security.security_protocol,
            SecurityProtocol::Ssl | SecurityProtocol::SaslSsl
        );

        if use_tls {
            debug!("Establishing TLS connection to {}", server);

            // Build TLS config using security settings (custom CA, mTLS support)
            let tls_config = super::tls::build_tls_config(&self.config.security)?;

            let connector = TlsConnector::from(Arc::new(tls_config));

            // Extract hostname from server address (host:port)
            let hostname = server.split(':').next().unwrap_or(server);

            let server_name = ServerName::try_from(hostname.to_string()).map_err(|e| {
                KafkaError::ConnectionFailed {
                    broker: server.to_string(),
                    message: format!("Invalid server name for TLS: {}", e),
                }
            })?;

            let tls_stream = connector
                .connect(server_name, tcp_stream)
                .await
                .map_err(|e| KafkaError::ConnectionFailed {
                    broker: server.to_string(),
                    message: format!("TLS handshake failed: {}", e),
                })?;

            debug!("TLS connection established to {}", server);
            Ok(ConnectionStream::Tls(Box::new(tls_stream)))
        } else {
            Ok(ConnectionStream::Plain(tcp_stream))
        }
    }

    /// Configure TCP socket options (keepalive, nodelay) based on connection config.
    fn configure_socket(&self, stream: &TcpStream, server: &str) -> Result<()> {
        let conn_config = &self.config.connection;

        // Get socket reference for configuration
        let sock_ref = SockRef::from(stream);

        // Enable TCP_NODELAY if configured
        if conn_config.tcp_nodelay {
            sock_ref
                .set_nodelay(true)
                .map_err(|e| KafkaError::ConnectionFailed {
                    broker: server.to_string(),
                    message: format!("Failed to set TCP_NODELAY: {}", e),
                })?;
        }

        // Configure TCP keepalive if enabled
        if conn_config.tcp_keepalive {
            let keepalive = TcpKeepalive::new()
                .with_time(Duration::from_secs(conn_config.keepalive_time_secs))
                .with_interval(Duration::from_secs(conn_config.keepalive_interval_secs));

            sock_ref
                .set_tcp_keepalive(&keepalive)
                .map_err(|e| KafkaError::ConnectionFailed {
                    broker: server.to_string(),
                    message: format!("Failed to set TCP keepalive: {}", e),
                })?;

            debug!(
                "TCP keepalive enabled for {}: time={}s, interval={}s",
                server, conn_config.keepalive_time_secs, conn_config.keepalive_interval_secs
            );
        }

        Ok(())
    }

    async fn authenticate(&self, broker_endpoint: &str) -> Result<()> {
        let security = &self.config.security;

        if let Some(factory) = security.sasl_mechanism_plugin_factory.clone() {
            // Use the endpoint that `try_connect` actually dialed. The
            // bootstrap client may skip earlier configured entries if they
            // are down; GSSAPI and MSK IAM both need the successful broker
            // host/port when constructing mechanism-specific payloads.
            let (host, port) = parse_broker_endpoint(broker_endpoint);
            let plugin = factory.build(&host, port).map_err(|e| {
                crate::Error::Authentication(format!(
                    "SASL plugin factory failed for broker {host}:{port}: {e}"
                ))
            })?;
            return self.sasl_plugin_auth(plugin).await;
        }

        match security.sasl_mechanism {
            Some(SaslMechanism::Plain) => {
                self.sasl_plain_auth(
                    security.sasl_username.as_deref().unwrap_or(""),
                    security.sasl_password.as_deref().unwrap_or(""),
                )
                .await
            }
            Some(mechanism @ SaslMechanism::ScramSha256)
            | Some(mechanism @ SaslMechanism::ScramSha512) => {
                self.sasl_scram_auth(
                    security.sasl_username.as_deref().unwrap_or(""),
                    security.sasl_password.as_deref().unwrap_or(""),
                    mechanism,
                )
                .await
            }
            Some(SaslMechanism::Gssapi) => {
                // GSSAPI is only supported through the plugin-factory
                // path. If we reach here, the CLI layer did not install
                // a factory — either the binary was built without
                // `--features gssapi` or `populate_sasl_plugin` was not
                // called on the config.
                Err(crate::Error::Authentication(
                    "sasl_mechanism: GSSAPI requires a \
                     SaslMechanismPluginFactory (install via CLI built \
                     with --features gssapi)"
                        .to_string(),
                ))
            }
            None => Ok(()), // No authentication needed
        }
    }

    /// Drive a handshake through a [`SaslMechanismPlugin`]. The client owns
    /// the wire protocol (`SaslHandshake` + repeated `SaslAuthenticate`);
    /// the plugin owns the mechanism-specific bytes.
    async fn sasl_plugin_auth(&self, plugin: super::SaslMechanismPluginHandle) -> Result<()> {
        use super::sasl::SaslAuthOutcome;
        use kafka_protocol::messages::{SaslAuthenticateRequest, SaslHandshakeRequest};

        let mechanism_name = plugin.mechanism_name().to_string();

        let handshake =
            SaslHandshakeRequest::default().with_mechanism(mechanism_name.clone().into());
        let _handshake_resp: kafka_protocol::messages::SaslHandshakeResponse =
            self.send_request(ApiKey::SaslHandshake, handshake).await?;

        let mut payload = plugin
            .initial_payload()
            .await
            .map_err(|e| crate::Error::Authentication(e.to_string()))?;

        loop {
            let req =
                SaslAuthenticateRequest::default().with_auth_bytes(Bytes::from(payload.clone()));
            let resp: kafka_protocol::messages::SaslAuthenticateResponse =
                self.send_request(ApiKey::SaslAuthenticate, req).await?;

            if resp.error_code != 0 {
                // Let the plugin interpret the server-side error body
                // (RFC 7628 JSON or Kafka 3.5+ free-form text).
                let err_bytes: Vec<u8> = resp
                    .error_message
                    .as_ref()
                    .map(|s| s.as_bytes().to_vec())
                    .unwrap_or_default();
                return Err(crate::Error::Authentication(
                    plugin.interpret_server_error(&err_bytes).to_string(),
                ));
            }

            match plugin
                .continue_payload(&resp.auth_bytes)
                .await
                .map_err(|e| crate::Error::Authentication(e.to_string()))?
            {
                SaslAuthOutcome::Continue(next) => payload = next,
                SaslAuthOutcome::Done => {
                    debug!("SASL {} plugin authentication successful", mechanism_name);
                    if plugin.supports_reauth() {
                        super::sasl::reauth::spawn_reauth_task(
                            Arc::downgrade(&self.connection),
                            self.correlation_id.clone(),
                            plugin.clone(),
                            resp.session_lifetime_ms,
                        );
                    } else {
                        debug!(
                            "SASL {} plugin opted out of live re-authentication; \
                             connection will expire and reconnect on next RPC",
                            mechanism_name
                        );
                    }
                    return Ok(());
                }
            }
        }
    }

    async fn sasl_plain_auth(&self, username: &str, password: &str) -> Result<()> {
        use kafka_protocol::messages::{SaslAuthenticateRequest, SaslHandshakeRequest};

        // Step 1: SASL Handshake
        let handshake_request = SaslHandshakeRequest::default().with_mechanism("PLAIN".into());
        let _handshake_response: kafka_protocol::messages::SaslHandshakeResponse = self
            .send_request(ApiKey::SaslHandshake, handshake_request)
            .await?;

        // Step 2: SASL Authenticate with PLAIN mechanism
        // PLAIN format: \0username\0password
        let mut auth_bytes = Vec::new();
        auth_bytes.push(0); // authzid (empty)
        auth_bytes.extend_from_slice(username.as_bytes());
        auth_bytes.push(0);
        auth_bytes.extend_from_slice(password.as_bytes());

        let auth_request =
            SaslAuthenticateRequest::default().with_auth_bytes(Bytes::from(auth_bytes));
        let auth_response: kafka_protocol::messages::SaslAuthenticateResponse = self
            .send_request(ApiKey::SaslAuthenticate, auth_request)
            .await?;

        if auth_response.error_code != 0 {
            return Err(crate::Error::Authentication(format!(
                "SASL authentication failed: {}",
                auth_response
                    .error_message
                    .map(|s| s.to_string())
                    .unwrap_or_else(|| format!("error code {}", auth_response.error_code))
            )));
        }

        debug!("SASL PLAIN authentication successful");
        Ok(())
    }

    /// SCRAM-SHA-256/512 authentication using send_request (with auto-reconnect).
    async fn sasl_scram_auth(
        &self,
        username: &str,
        password: &str,
        mechanism: SaslMechanism,
    ) -> Result<()> {
        use super::scram::{ScramAlgorithm, ScramClient};
        use kafka_protocol::messages::{SaslAuthenticateRequest, SaslHandshakeRequest};

        let algorithm = ScramAlgorithm::from_mechanism(mechanism).ok_or_else(|| {
            crate::Error::Authentication(format!("Unsupported SCRAM mechanism: {:?}", mechanism))
        })?;

        // Step 1: SASL Handshake
        let handshake_request =
            SaslHandshakeRequest::default().with_mechanism(algorithm.mechanism_name().into());
        let _handshake_response: kafka_protocol::messages::SaslHandshakeResponse = self
            .send_request(ApiKey::SaslHandshake, handshake_request)
            .await?;

        // Step 2: Client-first message
        let mut scram_client = ScramClient::new(algorithm, username, password)?;
        let client_first = scram_client.client_first_message();

        let auth_request =
            SaslAuthenticateRequest::default().with_auth_bytes(Bytes::from(client_first));
        let server_first_response: kafka_protocol::messages::SaslAuthenticateResponse = self
            .send_request(ApiKey::SaslAuthenticate, auth_request)
            .await?;

        if server_first_response.error_code != 0 {
            return Err(crate::Error::Authentication(format!(
                "SCRAM handshake failed: {}",
                server_first_response
                    .error_message
                    .map(|s| s.to_string())
                    .unwrap_or_else(|| format!("error code {}", server_first_response.error_code))
            )));
        }

        // Step 3: Process server-first, send client-final
        let client_final = scram_client.process_server_first(&server_first_response.auth_bytes)?;

        let auth_request =
            SaslAuthenticateRequest::default().with_auth_bytes(Bytes::from(client_final));
        let server_final_response: kafka_protocol::messages::SaslAuthenticateResponse = self
            .send_request(ApiKey::SaslAuthenticate, auth_request)
            .await?;

        if server_final_response.error_code != 0 {
            return Err(crate::Error::Authentication(format!(
                "SCRAM authentication failed: {}",
                server_final_response
                    .error_message
                    .map(|s| s.to_string())
                    .unwrap_or_else(|| {
                        format!("error code {}", server_final_response.error_code)
                    })
            )));
        }

        // Step 4: Verify server signature
        scram_client.process_server_final(&server_final_response.auth_bytes)?;

        debug!(
            "SASL {} authentication successful",
            algorithm.mechanism_name()
        );
        Ok(())
    }

    /// Send a request and receive a response.
    ///
    /// On connection errors (connection reset/aborted, broken pipe, EOF,
    /// timeouts — see [`super::connection_error`]), automatically reconnects
    /// and retries once. This handles TCP connections dropped by cloud Kafka
    /// providers during idle periods and by Windows Winsock (issue #146).
    ///
    /// Note: Reconnection with retry is skipped for SASL auth requests to avoid
    /// infinite recursion (connect -> authenticate -> send_request -> reconnect -> connect...).
    pub async fn send_request<Req, Resp>(&self, api_key: ApiKey, request: Req) -> Result<Resp>
    where
        Req: Encodable + Default,
        Resp: Decodable + Default,
    {
        let buf = self.encode_request(api_key, &request)?;

        // Skip reconnect retry for authentication requests to avoid recursion
        let can_retry = !matches!(api_key, ApiKey::SaslHandshake | ApiKey::SaslAuthenticate);

        // First attempt
        match self.send_raw_request::<Resp>(api_key, &buf).await {
            Ok(response) => Ok(response),
            Err(e) if can_retry && Self::is_connection_error(&e) => {
                warn!(
                    "Connection error on {:?} request, reconnecting and retrying: {}",
                    api_key, e
                );
                // Reconnect (full connect + authenticate)
                self.reconnect().await?;
                // Retry once with fresh connection
                self.send_raw_request::<Resp>(api_key, &buf).await
            }
            Err(e) => Err(e),
        }
    }

    /// Public wrapper for integration tests that verify timeout classification.
    pub fn is_connection_error_pub(error: &crate::Error) -> bool {
        Self::is_connection_error(error)
    }

    /// Check if an error is a connection-level error that warrants reconnection.
    ///
    /// Delegates to [`super::connection_error::is_connection_error`], which
    /// classifies by `io::ErrorKind` / OS error code rather than message text
    /// (issue #146).
    fn is_connection_error(error: &crate::Error) -> bool {
        super::connection_error::is_connection_error(error)
    }

    /// Reconnect to the Kafka cluster, dropping the existing connection.
    ///
    /// This re-establishes the TCP (and TLS) connection and performs SASL
    /// authentication directly (without going through send_request) to
    /// avoid async recursion.
    async fn reconnect(&self) -> Result<()> {
        {
            let mut conn = self.connection.lock().await;
            *conn = None; // Drop the old connection
        }

        // Re-establish TCP/TLS connection
        for server in &self.config.bootstrap_servers {
            match self.try_connect(server).await {
                Ok(stream) => {
                    let mut conn = self.connection.lock().await;
                    *conn = Some(BrokerConnection {
                        stream,
                        broker_id: -1,
                    });

                    // Re-authenticate if needed. `authenticate` routes through
                    // `send_request`, but `can_retry` is false for
                    // SaslHandshake/SaslAuthenticate (see `send_request`),
                    // so no runtime recursion into `reconnect` is possible.
                    // The `Box::pin` indirection is only there to satisfy
                    // the compiler's static recursion check.
                    if self.config.security.security_protocol == SecurityProtocol::SaslPlaintext
                        || self.config.security.security_protocol == SecurityProtocol::SaslSsl
                    {
                        drop(conn);
                        Box::pin(self.authenticate(server)).await?;
                    }

                    debug!("Reconnected to Kafka broker: {}", server);
                    return Ok(());
                }
                Err(e) => {
                    debug!("Failed to reconnect to {}: {}", server, e);
                    continue;
                }
            }
        }

        Err(KafkaError::NoBrokersAvailable.into())
    }

    /// Encode a request into a wire-format buffer.
    fn encode_request<Req: Encodable + Default>(
        &self,
        api_key: ApiKey,
        request: &Req,
    ) -> Result<Bytes> {
        encode_kafka_request(
            &self.correlation_id,
            api_key,
            self.get_api_version(api_key),
            request,
        )
    }

    /// Send an already-encoded request and read/decode the response.
    async fn send_raw_request<Resp>(&self, api_key: ApiKey, buf: &[u8]) -> Result<Resp>
    where
        Resp: Decodable + Default,
    {
        let api_version = self.get_api_version(api_key);
        let mut conn = self.connection.lock().await;
        let conn = conn.as_mut().ok_or_else(|| KafkaError::ConnectionIo {
            operation: "send request".to_string(),
            kind: std::io::ErrorKind::NotConnected,
            raw_os_error: None,
            message: "Not connected".to_string(),
        })?;

        send_rpc_on_stream(&mut conn.stream, api_key, api_version, buf).await
    }

    /// Get the API version to use for a given API key
    fn get_api_version(&self, api_key: ApiKey) -> i16 {
        // Use reasonable default versions that are widely supported
        match api_key {
            ApiKey::Metadata => 9,
            ApiKey::Fetch => 11,
            ApiKey::Produce => 8,
            ApiKey::SaslHandshake => 1,
            ApiKey::SaslAuthenticate => 2,
            ApiKey::ApiVersions => 3,
            ApiKey::ListOffsets => 5,
            ApiKey::CreateTopics => 5, // v5 supported since Kafka 2.4
            ApiKey::FindCoordinator => 2,
            ApiKey::OffsetFetch => 5,
            ApiKey::OffsetCommit => 5,
            ApiKey::ListGroups => 2,
            ApiKey::DeleteRecords => 1,
            ApiKey::DescribeConfigs => 1,
            ApiKey::IncrementalAlterConfigs => 1,
            ApiKey::DescribeAcls => 1,
            ApiKey::CreateAcls => 1,
            ApiKey::DeleteAcls => 1,
            _ => 0,
        }
    }

    /// Fetch cluster metadata
    pub async fn fetch_metadata(&self, topics: Option<&[String]>) -> Result<Vec<TopicMetadata>> {
        super::metadata::fetch_metadata(self, topics).await
    }

    /// Get metadata for a specific topic
    pub async fn get_topic_metadata(&self, topic: &str) -> Result<TopicMetadata> {
        let topics = self.fetch_metadata(Some(&[topic.to_string()])).await?;
        topics
            .into_iter()
            .find(|t| t.name == topic)
            .ok_or_else(|| KafkaError::TopicNotExists(topic.to_string()).into())
    }

    /// Fetch records from a topic/partition
    pub async fn fetch(
        &self,
        topic: &str,
        partition: i32,
        offset: i64,
        max_bytes: i32,
    ) -> Result<FetchResponse> {
        super::fetch::fetch(self, topic, partition, offset, max_bytes).await
    }

    /// Get the earliest and latest offsets for a partition
    pub async fn get_offsets(&self, topic: &str, partition: i32) -> Result<(i64, i64)> {
        super::fetch::get_offsets(self, topic, partition).await
    }

    /// Produce records to a topic/partition
    pub async fn produce(
        &self,
        topic: &str,
        partition: i32,
        records: Vec<crate::manifest::BackupRecord>,
        acks: i16,
        timeout_ms: i32,
    ) -> Result<ProduceResponse> {
        super::produce::produce(self, topic, partition, records, acks, timeout_ms).await
    }

    /// Create topics in the Kafka cluster
    pub async fn create_topics(
        &self,
        topics: Vec<super::TopicToCreate>,
        timeout_ms: i32,
    ) -> Result<Vec<super::CreateTopicResult>> {
        super::admin::create_topics(self, topics, timeout_ms).await
    }

    /// Get cached broker metadata
    #[allow(dead_code)]
    pub async fn get_broker(&self, broker_id: i32) -> Option<BrokerMetadata> {
        let brokers = self.brokers.lock().await;
        brokers.get(&broker_id).cloned()
    }

    /// Update broker cache
    pub async fn update_brokers(&self, brokers: Vec<BrokerMetadata>) {
        let mut cache = self.brokers.lock().await;
        for broker in brokers {
            cache.insert(broker.node_id, broker);
        }
    }
}

/// Encode a Kafka request (header + body + length prefix) against a shared
/// correlation counter. Pulled out of `KafkaClient` so the KIP-368 re-auth
/// task in `sasl::reauth` can produce wire-compatible frames without
/// depending on an `&KafkaClient`.
pub(super) fn encode_kafka_request<Req: Encodable + Default>(
    correlation_id: &AtomicI32,
    api_key: ApiKey,
    api_version: i16,
    request: &Req,
) -> Result<Bytes> {
    let correlation_id = correlation_id.fetch_add(1, Ordering::SeqCst);

    let header = RequestHeader::default()
        .with_request_api_key(api_key as i16)
        .with_request_api_version(api_version)
        .with_correlation_id(correlation_id)
        .with_client_id(Some(StrBytes::from_static_str("kafka-backup")));

    let header_version = api_key.request_header_version(api_version);
    let mut buf = BytesMut::new();
    buf.put_i32(0);

    header
        .encode(&mut buf, header_version)
        .map_err(|e| KafkaError::Protocol(format!("Failed to encode header: {:?}", e)))?;
    request
        .encode(&mut buf, api_version)
        .map_err(|e| KafkaError::Protocol(format!("Failed to encode request: {:?}", e)))?;

    let len = (buf.len() - 4) as i32;
    buf[0..4].copy_from_slice(&len.to_be_bytes());

    trace!(
        "Sending request: api_key={:?}, api_version={}, correlation_id={}, len={}",
        api_key,
        api_version,
        correlation_id,
        len
    );

    Ok(buf.freeze())
}

/// Write an already-encoded frame to `stream`, read the response, and
/// decode it. Counterpart to [`encode_kafka_request`] for use by the
/// re-auth scheduler.
pub(super) async fn send_rpc_on_stream<Resp>(
    stream: &mut ConnectionStream,
    api_key: ApiKey,
    api_version: i16,
    buf: &[u8],
) -> Result<Resp>
where
    Resp: Decodable + Default,
{
    // I/O failures keep their `io::ErrorKind` / OS code (issue #146) so the
    // reconnect path can classify them without parsing localized OS text.
    timeout(
        Duration::from_secs(WRITE_TIMEOUT_SECS),
        stream.write_all(buf),
    )
    .await
    .map_err(|_| {
        request_timeout_error(
            "send request",
            format!(
                "Request timed out after {}s sending to broker",
                WRITE_TIMEOUT_SECS
            ),
        )
    })?
    .map_err(|e| connection_io_error("send request", &e))?;

    let mut len_buf = [0u8; 4];
    timeout(
        Duration::from_secs(RESPONSE_TIMEOUT_SECS),
        stream.read_exact(&mut len_buf),
    )
    .await
    .map_err(|_| {
        request_timeout_error(
            "read response length",
            format!(
                "Request timed out after {}s waiting for broker response",
                RESPONSE_TIMEOUT_SECS
            ),
        )
    })?
    .map_err(|e| connection_io_error("read response length", &e))?;
    let response_len = i32::from_be_bytes(len_buf) as usize;

    trace!("Receiving response: len={}", response_len);

    let mut response_buf = vec![0u8; response_len];
    timeout(
        Duration::from_secs(RESPONSE_TIMEOUT_SECS),
        stream.read_exact(&mut response_buf),
    )
    .await
    .map_err(|_| {
        request_timeout_error(
            "read response body",
            format!(
                "Response body read timed out after {}s",
                RESPONSE_TIMEOUT_SECS
            ),
        )
    })?
    .map_err(|e| connection_io_error("read response body", &e))?;

    let mut response_bytes = Bytes::from(response_buf);
    let response_header_version = api_key.response_header_version(api_version);
    let _response_header = ResponseHeader::decode(&mut response_bytes, response_header_version)
        .map_err(|e| KafkaError::Protocol(format!("Failed to decode response header: {:?}", e)))?;

    let response = Resp::decode(&mut response_bytes, api_version)
        .map_err(|e| KafkaError::Protocol(format!("Failed to decode response: {:?}", e)))?;

    Ok(response)
}

/// Split a bootstrap entry into `(host, port)`. Accepts `host:port`,
/// bare `host` (defaults to 9092, the Kafka convention), and IPv6
/// literals in the `[::1]:9092` form.
///
/// Used by [`KafkaClient::authenticate`] to feed the broker endpoint
/// into a [`crate::kafka::SaslMechanismPluginFactory`].
pub(super) fn parse_broker_endpoint(entry: &str) -> (String, u16) {
    const DEFAULT_PORT: u16 = 9092;

    // IPv6 literal: `[::1]:9092` or bare `[::1]`.
    if let Some(rest) = entry.strip_prefix('[') {
        if let Some(end) = rest.find(']') {
            let host = rest[..end].to_string();
            let after = &rest[end + 1..];
            let port = after
                .strip_prefix(':')
                .and_then(|p| p.parse::<u16>().ok())
                .unwrap_or(DEFAULT_PORT);
            return (host, port);
        }
    }

    match entry.rsplit_once(':') {
        Some((host, port_str)) => {
            let port = port_str.parse::<u16>().unwrap_or(DEFAULT_PORT);
            (host.to_string(), port)
        }
        None => (entry.to_string(), DEFAULT_PORT),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::ConnectionConfig;
    use std::net::TcpListener;

    #[test]
    fn parse_broker_endpoint_host_port() {
        let (host, port) = parse_broker_endpoint("kafka.example.com:9093");
        assert_eq!(host, "kafka.example.com");
        assert_eq!(port, 9093);
    }

    #[test]
    fn parse_broker_endpoint_bare_host_defaults_port() {
        let (host, port) = parse_broker_endpoint("kafka.example.com");
        assert_eq!(host, "kafka.example.com");
        assert_eq!(port, 9092);
    }

    #[test]
    fn parse_broker_endpoint_ipv6_with_port() {
        let (host, port) = parse_broker_endpoint("[::1]:9094");
        assert_eq!(host, "::1");
        assert_eq!(port, 9094);
    }

    #[test]
    fn parse_broker_endpoint_ipv6_without_port() {
        let (host, port) = parse_broker_endpoint("[::1]");
        assert_eq!(host, "::1");
        assert_eq!(port, 9092);
    }

    #[test]
    fn parse_broker_endpoint_malformed_port_falls_back_to_default() {
        // "host:not-a-port" — we recover rather than panic, and let the
        // connect step surface the real failure if the entry is bad.
        let (host, port) = parse_broker_endpoint("kafka.example.com:abc");
        assert_eq!(host, "kafka.example.com");
        assert_eq!(port, 9092);
    }

    /// Test that TCP keepalive settings are actually applied to the socket.
    /// This creates a real TCP connection and verifies the socket options.
    #[tokio::test]
    async fn test_tcp_keepalive_is_applied() {
        // Start a local TCP listener
        let listener = TcpListener::bind("127.0.0.1:0").expect("Failed to bind listener");
        let addr = listener.local_addr().expect("Failed to get local addr");

        // Connect to the listener
        let tcp_stream = TcpStream::connect(addr).await.expect("Failed to connect");

        // Create a KafkaConfig with TCP keepalive enabled
        let config = KafkaConfig {
            bootstrap_servers: vec![addr.to_string()],
            security: Default::default(),
            topics: Default::default(),
            connection: ConnectionConfig {
                tcp_keepalive: true,
                keepalive_time_secs: 60,
                keepalive_interval_secs: 20,
                tcp_nodelay: true,
                ..Default::default()
            },
        };

        let client = KafkaClient::new(config);

        // Apply socket configuration
        client
            .configure_socket(&tcp_stream, &addr.to_string())
            .expect("Failed to configure socket");

        // Verify the settings were applied using socket2
        let sock_ref = SockRef::from(&tcp_stream);

        // Check TCP_NODELAY is set
        let nodelay = sock_ref.nodelay().expect("Failed to get nodelay");
        assert!(nodelay, "TCP_NODELAY should be enabled");

        // Check keepalive is enabled
        // Note: socket2 doesn't have a direct getter for keepalive enabled,
        // but we can verify the keepalive settings were set without error.
        // On macOS, we can check the keepalive time.
        #[cfg(any(target_os = "macos", target_os = "ios"))]
        {
            let keepalive_time = sock_ref
                .keepalive_time()
                .expect("Failed to get keepalive time");
            assert_eq!(
                keepalive_time,
                Duration::from_secs(60),
                "Keepalive time should be 60 seconds"
            );
        }

        // On Linux, we can check both time and interval
        #[cfg(target_os = "linux")]
        {
            let keepalive_time = sock_ref
                .keepalive_time()
                .expect("Failed to get keepalive time");
            assert_eq!(
                keepalive_time,
                Duration::from_secs(60),
                "Keepalive time should be 60 seconds"
            );

            let keepalive_interval = sock_ref
                .keepalive_interval()
                .expect("Failed to get keepalive interval");
            assert_eq!(
                keepalive_interval,
                Duration::from_secs(20),
                "Keepalive interval should be 20 seconds"
            );
        }

        println!("TCP keepalive settings verified successfully!");
    }

    /// Test that TCP keepalive can be disabled via configuration.
    #[tokio::test]
    async fn test_tcp_keepalive_disabled() {
        let listener = TcpListener::bind("127.0.0.1:0").expect("Failed to bind listener");
        let addr = listener.local_addr().expect("Failed to get local addr");

        let tcp_stream = TcpStream::connect(addr).await.expect("Failed to connect");

        // Create a KafkaConfig with TCP keepalive DISABLED
        let config = KafkaConfig {
            bootstrap_servers: vec![addr.to_string()],
            security: Default::default(),
            topics: Default::default(),
            connection: ConnectionConfig {
                tcp_keepalive: false,
                keepalive_time_secs: 60,
                keepalive_interval_secs: 20,
                tcp_nodelay: false,
                ..Default::default()
            },
        };

        let client = KafkaClient::new(config);

        // Apply socket configuration - should succeed even with keepalive disabled
        client
            .configure_socket(&tcp_stream, &addr.to_string())
            .expect("Failed to configure socket");

        // Verify TCP_NODELAY is NOT set
        let sock_ref = SockRef::from(&tcp_stream);
        let nodelay = sock_ref.nodelay().expect("Failed to get nodelay");
        assert!(!nodelay, "TCP_NODELAY should be disabled");

        println!("TCP keepalive disabled configuration verified!");
    }

    /// Test custom keepalive values
    #[tokio::test]
    async fn test_tcp_keepalive_custom_values() {
        let listener = TcpListener::bind("127.0.0.1:0").expect("Failed to bind listener");
        let addr = listener.local_addr().expect("Failed to get local addr");

        let tcp_stream = TcpStream::connect(addr).await.expect("Failed to connect");

        // Create a KafkaConfig with custom keepalive values
        let config = KafkaConfig {
            bootstrap_servers: vec![addr.to_string()],
            security: Default::default(),
            topics: Default::default(),
            connection: ConnectionConfig {
                tcp_keepalive: true,
                keepalive_time_secs: 30,     // Custom: 30 seconds
                keepalive_interval_secs: 10, // Custom: 10 seconds
                tcp_nodelay: true,
                ..Default::default()
            },
        };

        let client = KafkaClient::new(config);
        client
            .configure_socket(&tcp_stream, &addr.to_string())
            .expect("Failed to configure socket");

        let sock_ref = SockRef::from(&tcp_stream);

        #[cfg(any(target_os = "macos", target_os = "ios", target_os = "linux"))]
        {
            let keepalive_time = sock_ref
                .keepalive_time()
                .expect("Failed to get keepalive time");
            assert_eq!(
                keepalive_time,
                Duration::from_secs(30),
                "Custom keepalive time should be 30 seconds"
            );
        }

        #[cfg(target_os = "linux")]
        {
            let keepalive_interval = sock_ref
                .keepalive_interval()
                .expect("Failed to get keepalive interval");
            assert_eq!(
                keepalive_interval,
                Duration::from_secs(10),
                "Custom keepalive interval should be 10 seconds"
            );
        }

        println!("Custom TCP keepalive values verified!");
    }
}
