//! Partition leader routing for multi-broker Kafka clusters.
//!
//! This module provides a router that directs fetch/produce requests to the
//! correct broker based on partition leadership. In multi-broker clusters,
//! different brokers are leaders for different partitions, and requests must
//! be sent to the leader to avoid NOT_LEADER_FOR_PARTITION errors.

use std::collections::HashMap;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::Duration;
use tokio::sync::RwLock;
use tracing::{debug, info, warn};

use crate::config::KafkaConfig;
use crate::error::KafkaError;
use crate::Result;

use super::metadata::{BrokerMetadata, PartitionMetadata, TopicMetadata};
use super::{FetchResponse, KafkaClient, ProduceResponse};
use crate::manifest::BackupRecord;

const COORDINATOR_LOAD_IN_PROGRESS: i16 = 14;
const COORDINATOR_NOT_AVAILABLE: i16 = 15;
const NOT_COORDINATOR: i16 = 16;
const MAX_COORDINATOR_RETRIES: u32 = 12;

/// Routes Kafka requests to the correct partition leader broker.
///
/// This router maintains:
/// - A mapping of (topic, partition) -> leader broker ID
/// - A connection pool to all discovered brokers
/// - Automatic metadata refresh on leadership changes
pub struct PartitionLeaderRouter {
    /// Bootstrap servers for initial connection and metadata refresh
    #[allow(dead_code)]
    bootstrap_servers: Vec<String>,

    /// Kafka configuration (for creating new connections)
    config: KafkaConfig,

    /// Map of broker_id -> BrokerMetadata (host:port info)
    broker_metadata: Arc<RwLock<HashMap<i32, BrokerMetadata>>>,

    /// Map of (topic, partition) -> leader broker_id
    partition_leaders: Arc<RwLock<HashMap<(String, i32), i32>>>,

    /// Connection pool: broker_id -> Vec of KafkaClients
    /// Multiple connections per broker allow parallel in-flight requests,
    /// preventing the single-connection mutex from becoming a bottleneck
    /// on high-latency connections (Issue #29).
    connections: Arc<RwLock<HashMap<i32, Vec<Arc<KafkaClient>>>>>,

    /// Round-robin counter for distributing requests across connections
    connection_index: AtomicUsize,

    /// Bootstrap client for metadata operations
    bootstrap_client: Arc<KafkaClient>,
}

impl PartitionLeaderRouter {
    /// Create a new partition leader router.
    ///
    /// This connects to the bootstrap servers, fetches cluster metadata,
    /// and builds the initial partition leader map.
    pub async fn new(config: KafkaConfig) -> Result<Self> {
        let bootstrap_servers = config.bootstrap_servers.clone();

        // Create and connect bootstrap client
        let bootstrap_client = Arc::new(KafkaClient::new(config.clone()));
        bootstrap_client.connect().await?;

        let router = Self {
            bootstrap_servers,
            config,
            broker_metadata: Arc::new(RwLock::new(HashMap::new())),
            partition_leaders: Arc::new(RwLock::new(HashMap::new())),
            connections: Arc::new(RwLock::new(HashMap::new())),
            connection_index: AtomicUsize::new(0),
            bootstrap_client,
        };

        // Fetch initial metadata
        router.refresh_metadata().await?;

        Ok(router)
    }

    /// Refresh cluster metadata and update partition leader mappings.
    ///
    /// This should be called periodically or when a NOT_LEADER_FOR_PARTITION
    /// error is encountered.
    pub async fn refresh_metadata(&self) -> Result<()> {
        debug!("Refreshing cluster metadata");

        // Fetch all topics metadata
        let topics = self.bootstrap_client.fetch_metadata(None).await?;

        // Get broker metadata from the client's cache
        let brokers = {
            // The fetch_metadata call updates the brokers cache internally
            // We need to re-fetch it
            let broker_list = self.get_brokers_from_topics(&topics).await?;
            broker_list
        };

        // Update broker metadata
        {
            let mut broker_meta = self.broker_metadata.write().await;
            broker_meta.clear();
            for broker in brokers {
                debug!(
                    "Discovered broker {}: {}:{}",
                    broker.node_id, broker.host, broker.port
                );
                broker_meta.insert(broker.node_id, broker);
            }
        }

        // Update partition leaders
        {
            let mut leaders = self.partition_leaders.write().await;
            leaders.clear();

            for topic in &topics {
                for partition in &topic.partitions {
                    leaders.insert(
                        (topic.name.clone(), partition.partition_id),
                        partition.leader_id,
                    );
                    debug!(
                        "Partition {}/{} leader: broker {}",
                        topic.name, partition.partition_id, partition.leader_id
                    );
                }
            }

            info!(
                "Refreshed metadata: {} brokers, {} partition leaders",
                self.broker_metadata.read().await.len(),
                leaders.len()
            );
        }

        Ok(())
    }

    /// Get brokers from metadata response by re-fetching metadata
    async fn get_brokers_from_topics(
        &self,
        _topics: &[TopicMetadata],
    ) -> Result<Vec<BrokerMetadata>> {
        // Re-fetch metadata to get broker info - the fetch_metadata call
        // updates the internal broker cache
        use kafka_protocol::messages::{ApiKey, MetadataRequest, MetadataResponse};

        let request = MetadataRequest::default()
            .with_topics(None)
            .with_allow_auto_topic_creation(false);

        let response: MetadataResponse = self
            .bootstrap_client
            .send_request(ApiKey::Metadata, request)
            .await?;

        let brokers: Vec<BrokerMetadata> = response
            .brokers
            .iter()
            .map(|broker| BrokerMetadata {
                node_id: broker.node_id.0,
                host: broker.host.to_string(),
                port: broker.port,
                rack: broker.rack.as_ref().map(|r| r.to_string()),
            })
            .collect();

        Ok(brokers)
    }

    /// Refresh metadata for a specific topic/partition.
    ///
    /// Use this for targeted refresh after a NOT_LEADER_FOR_PARTITION error.
    pub async fn refresh_partition_leader(&self, topic: &str, partition: i32) -> Result<()> {
        debug!("Refreshing leader for {}/{}", topic, partition);

        // Fetch metadata for just this topic
        let topics = self
            .bootstrap_client
            .fetch_metadata(Some(&[topic.to_string()]))
            .await?;

        // Also refresh broker metadata
        let brokers = self.get_brokers_from_topics(&topics).await?;
        {
            let mut broker_meta = self.broker_metadata.write().await;
            for broker in brokers {
                broker_meta.insert(broker.node_id, broker);
            }
        }

        // Update the specific partition leader
        for t in topics {
            if t.name == topic {
                for p in t.partitions {
                    if p.partition_id == partition {
                        let mut leaders = self.partition_leaders.write().await;
                        leaders.insert((topic.to_string(), partition), p.leader_id);
                        info!(
                            "Updated leader for {}/{}: broker {}",
                            topic, partition, p.leader_id
                        );
                        return Ok(());
                    }
                }
            }
        }

        Err(KafkaError::PartitionNotAvailable {
            topic: topic.to_string(),
            partition,
        }
        .into())
    }

    /// Get the leader broker ID for a partition.
    ///
    /// If the topic is not in the cache (e.g. newly created after the router was
    /// initialised), refreshes partition-leader metadata from the cluster once before
    /// returning an error.  This prevents `PartitionNotAvailable` failures for
    /// topics discovered between continuous-backup cycles.
    pub async fn get_leader(&self, topic: &str, partition: i32) -> Result<i32> {
        {
            let leaders = self.partition_leaders.read().await;
            if let Some(&id) = leaders.get(&(topic.to_string(), partition)) {
                return Ok(id);
            }
        }

        // Topic not found in cache — refresh and retry once
        debug!(
            "Leader for {}:{} not in cache, refreshing metadata",
            topic, partition
        );
        self.refresh_partition_leader(topic, partition).await?;

        let leaders = self.partition_leaders.read().await;
        leaders
            .get(&(topic.to_string(), partition))
            .copied()
            .ok_or_else(|| {
                KafkaError::PartitionNotAvailable {
                    topic: topic.to_string(),
                    partition,
                }
                .into()
            })
    }

    /// Get or create a connection to a specific broker.
    ///
    /// Maintains a pool of N connections per broker (configured via
    /// `connections_per_broker`). Uses round-robin selection to distribute
    /// requests across connections, reducing mutex contention.
    async fn get_broker_connection(&self, broker_id: i32) -> Result<Arc<KafkaClient>> {
        let pool_size = self.config.connection.connections_per_broker.max(1);

        // Check if we already have a full pool
        {
            let connections = self.connections.read().await;
            if let Some(pool) = connections.get(&broker_id) {
                if pool.len() >= pool_size {
                    // Round-robin selection
                    let idx = self.connection_index.fetch_add(1, Ordering::Relaxed) % pool.len();
                    return Ok(Arc::clone(&pool[idx]));
                }
            }
        }

        // Get broker address
        let broker_addr = {
            let brokers = self.broker_metadata.read().await;
            let broker = brokers
                .get(&broker_id)
                .ok_or_else(|| KafkaError::Protocol(format!("Unknown broker ID: {}", broker_id)))?;
            format!("{}:{}", broker.host, broker.port)
        };

        // Create the full pool of connections
        debug!(
            "Creating {} connections to broker {} at {}",
            pool_size, broker_id, broker_addr
        );

        let mut pool = Vec::with_capacity(pool_size);
        for _ in 0..pool_size {
            let mut broker_config = self.config.clone();
            broker_config.bootstrap_servers = vec![broker_addr.clone()];

            let client = Arc::new(KafkaClient::new(broker_config));
            client.connect().await?;
            pool.push(client);
        }

        // Store in connection pool and return one via round-robin
        let idx = self.connection_index.fetch_add(1, Ordering::Relaxed) % pool.len();
        let selected = Arc::clone(&pool[idx]);

        {
            let mut connections = self.connections.write().await;
            connections.insert(broker_id, pool);
        }

        Ok(selected)
    }

    /// Get a client connected to the partition's leader broker.
    pub async fn get_leader_client(&self, topic: &str, partition: i32) -> Result<Arc<KafkaClient>> {
        let leader_id = self.get_leader(topic, partition).await?;
        self.get_broker_connection(leader_id).await
    }

    /// Fetch records from a partition, routing to the correct leader.
    ///
    /// Handles the same two failure classes as [`Self::produce`]:
    ///
    /// 1. `NOT_LEADER_FOR_PARTITION` (error code 6): refreshes the partition-leader
    ///    cache and retries once.
    ///
    /// 2. Connection errors (see [`super::connection_error`]): retries up to
    ///    `MAX_CONNECTION_RETRIES` times with linear back-off, dropping the cached
    ///    broker connections in between. `KafkaClient::send_request` already
    ///    reconnects and retries once *immediately*; this loop covers blips that
    ///    outlast that single retry — a proxy or broker resetting connections
    ///    for a second or two would otherwise fail the partition, and with it
    ///    the whole backup, hours in (issue #146).
    pub async fn fetch(
        &self,
        topic: &str,
        partition: i32,
        offset: i64,
        max_bytes: i32,
    ) -> Result<FetchResponse> {
        const MAX_CONNECTION_RETRIES: u32 = 5;

        let mut connection_attempts = 0;

        loop {
            match self
                .fetch_internal(topic, partition, offset, max_bytes)
                .await
            {
                Ok(response) => return Ok(response),
                Err(e) if is_not_leader_error(&e) => {
                    // Refresh metadata and retry once with the new leader
                    warn!(
                        "NOT_LEADER_FOR_PARTITION error for {}/{}, refreshing metadata",
                        topic, partition
                    );
                    self.refresh_partition_leader(topic, partition).await?;
                    self.clear_connection_cache().await;
                    return self
                        .fetch_internal(topic, partition, offset, max_bytes)
                        .await;
                }
                Err(e)
                    if is_connection_error(&e) && connection_attempts < MAX_CONNECTION_RETRIES =>
                {
                    connection_attempts += 1;
                    let backoff = Duration::from_millis(500 * connection_attempts as u64);
                    warn!(
                        "Connection error fetching {}/{} (attempt {}/{}), retrying after {:?}: {}",
                        topic, partition, connection_attempts, MAX_CONNECTION_RETRIES, backoff, e
                    );
                    self.clear_connection_cache().await;
                    tokio::time::sleep(backoff).await;
                }
                Err(e) => return Err(e),
            }
        }
    }

    /// Internal fetch implementation.
    async fn fetch_internal(
        &self,
        topic: &str,
        partition: i32,
        offset: i64,
        max_bytes: i32,
    ) -> Result<FetchResponse> {
        let client = self.get_leader_client(topic, partition).await?;
        client.fetch(topic, partition, offset, max_bytes).await
    }

    /// Batch get offsets for all given topic-partitions in minimal network calls.
    ///
    /// Groups partitions by their leader broker and sends one batched ListOffsetsRequest
    /// per broker per timestamp. For N partitions across B brokers, this makes 2*B requests
    /// (earliest + latest) instead of 2*N individual requests.
    ///
    /// Returns a map of (topic, partition) -> (earliest, latest) offset.
    pub async fn batch_get_all_offsets(
        &self,
        partitions: &[(String, i32)],
    ) -> Result<HashMap<(String, i32), (i64, i64)>> {
        // Group partitions by leader broker
        let mut broker_partitions: HashMap<i32, Vec<(String, i32)>> = HashMap::new();
        for (topic, partition) in partitions {
            let leader_id = self.get_leader(topic, *partition).await?;
            broker_partitions
                .entry(leader_id)
                .or_default()
                .push((topic.clone(), *partition));
        }

        debug!(
            "batch_get_all_offsets: {} partitions across {} brokers",
            partitions.len(),
            broker_partitions.len()
        );

        let mut all_results: HashMap<(String, i32), (i64, i64)> = HashMap::new();

        // For each broker, send one batched request for earliest and one for latest
        for (broker_id, broker_parts) in &broker_partitions {
            let client = self.get_broker_connection(*broker_id).await?;

            // Build earliest requests (timestamp = -2)
            let earliest_requests: Vec<(String, i32, i64)> = broker_parts
                .iter()
                .map(|(t, p)| (t.clone(), *p, -2i64))
                .collect();

            // Build latest requests (timestamp = -1)
            let latest_requests: Vec<(String, i32, i64)> = broker_parts
                .iter()
                .map(|(t, p)| (t.clone(), *p, -1i64))
                .collect();

            let earliest_offsets: HashMap<(String, i32), i64> =
                super::fetch::batch_get_offsets(&client, &earliest_requests).await?;
            let latest_offsets: HashMap<(String, i32), i64> =
                super::fetch::batch_get_offsets(&client, &latest_requests).await?;

            // Merge results
            for (topic, partition) in broker_parts {
                let key = (topic.clone(), *partition);
                let earliest = earliest_offsets.get(&key).copied().unwrap_or(0);
                let latest = latest_offsets.get(&key).copied().unwrap_or(0);
                all_results.insert(key, (earliest, latest));
            }
        }

        debug!(
            "batch_get_all_offsets: completed with {} results ({} broker calls)",
            all_results.len(),
            broker_partitions.len() * 2
        );

        Ok(all_results)
    }

    /// Get the earliest and latest offsets for a partition.
    pub async fn get_offsets(&self, topic: &str, partition: i32) -> Result<(i64, i64)> {
        // First attempt
        match self.get_offsets_internal(topic, partition).await {
            Ok(offsets) => Ok(offsets),
            Err(e) if is_not_leader_error(&e) => {
                // Refresh metadata and retry
                warn!(
                    "NOT_LEADER_FOR_PARTITION error for {}/{} during get_offsets, refreshing metadata",
                    topic, partition
                );
                self.refresh_partition_leader(topic, partition).await?;
                self.clear_connection_cache().await;
                self.get_offsets_internal(topic, partition).await
            }
            Err(e) => Err(e),
        }
    }

    /// Internal get_offsets implementation.
    async fn get_offsets_internal(&self, topic: &str, partition: i32) -> Result<(i64, i64)> {
        let client = self.get_leader_client(topic, partition).await?;
        client.get_offsets(topic, partition).await
    }

    /// Produce records to a partition, routing to the correct leader.
    ///
    /// Handles two failure classes (Issue #67 bug 8):
    ///
    /// 1. `NOT_LEADER_FOR_PARTITION` (error code 6): refreshes the partition-leader
    ///    cache and retries once. This covers planned leader elections and rolling
    ///    restarts.
    ///
    /// 2. Connection errors (broken pipe, timeout, etc.): retries up to
    ///    `MAX_CONNECTION_RETRIES` times with linear back-off. This covers transient
    ///    network blips and broker restarts.
    ///
    /// Records are only cloned when a retry is actually required.
    pub async fn produce(
        &self,
        topic: &str,
        partition: i32,
        records: Vec<BackupRecord>,
        acks: i16,
        timeout_ms: i32,
    ) -> Result<ProduceResponse> {
        const MAX_CONNECTION_RETRIES: u32 = 5;
        const MAX_LEADER_RETRIES: u32 = 20;

        let mut connection_attempts = 0;
        let mut leader_attempts = 0;

        loop {
            match self
                .produce_internal(topic, partition, &records, acks, timeout_ms)
                .await
            {
                Ok(response) => return Ok(response),
                Err(e) if is_not_leader_error(&e) && leader_attempts < MAX_LEADER_RETRIES => {
                    leader_attempts += 1;
                    let backoff = Duration::from_millis((250 * leader_attempts as u64).min(2_000));
                    warn!(
                        "NOT_LEADER_FOR_PARTITION for {}/{} (attempt {}/{}), refreshing metadata after {:?}: {}",
                        topic,
                        partition,
                        leader_attempts,
                        MAX_LEADER_RETRIES,
                        backoff,
                        e
                    );
                    self.refresh_partition_leader(topic, partition).await?;
                    self.clear_connection_cache().await;
                    tokio::time::sleep(backoff).await;
                }
                Err(e)
                    if is_connection_error(&e) && connection_attempts < MAX_CONNECTION_RETRIES =>
                {
                    connection_attempts += 1;
                    let backoff = Duration::from_millis(500 * connection_attempts as u64);
                    warn!(
                        "Connection error for {}/{} (attempt {}/{}), retrying after {:?}: {}",
                        topic, partition, connection_attempts, MAX_CONNECTION_RETRIES, backoff, e
                    );
                    self.clear_connection_cache().await;
                    tokio::time::sleep(backoff).await;
                }
                Err(e) => return Err(e),
            }
        }
    }

    /// Internal produce implementation — borrows records to avoid unnecessary cloning.
    async fn produce_internal(
        &self,
        topic: &str,
        partition: i32,
        records: &[BackupRecord],
        acks: i16,
        timeout_ms: i32,
    ) -> Result<ProduceResponse> {
        let client = self.get_leader_client(topic, partition).await?;
        client
            .produce(topic, partition, records.to_vec(), acks, timeout_ms)
            .await
    }

    /// Clear the connection cache (useful after metadata refresh).
    async fn clear_connection_cache(&self) {
        let mut connections = self.connections.write().await;
        connections.clear();
        debug!("Cleared connection cache");
    }

    /// Fetch metadata using the bootstrap client.
    ///
    /// This is useful for operations that don't need leader routing,
    /// such as listing topics.
    pub async fn fetch_metadata(&self, topics: Option<&[String]>) -> Result<Vec<TopicMetadata>> {
        self.bootstrap_client.fetch_metadata(topics).await
    }

    /// Create topics in the Kafka cluster.
    ///
    /// This sends the CreateTopics request to any broker (the broker will
    /// route to the controller internally).
    pub async fn create_topics(
        &self,
        topics: Vec<super::TopicToCreate>,
        timeout_ms: i32,
    ) -> Result<Vec<super::CreateTopicResult>> {
        self.bootstrap_client
            .create_topics(topics, timeout_ms)
            .await
    }

    /// Describe topic or broker configuration through the bootstrap client.
    pub async fn describe_configs(
        &self,
        resources: &[(super::ConfigResourceType, String)],
    ) -> Result<HashMap<(super::ConfigResourceType, String), Vec<super::ConfigEntry>>> {
        super::describe_configs(self.bootstrap_client.as_ref(), resources).await
    }

    /// Apply incremental configuration changes through the bootstrap client.
    pub async fn incremental_alter_configs(&self, changes: &[super::ConfigChange]) -> Result<()> {
        super::incremental_alter_configs(self.bootstrap_client.as_ref(), changes).await
    }

    /// Get metadata for a specific topic.
    pub async fn get_topic_metadata(&self, topic: &str) -> Result<TopicMetadata> {
        self.bootstrap_client.get_topic_metadata(topic).await
    }

    /// Access the bootstrap client for direct requests (e.g. OffsetFetch).
    pub fn bootstrap_client(&self) -> &KafkaClient {
        &self.bootstrap_client
    }

    /// Get partition metadata for a topic.
    pub async fn get_partitions(&self, topic: &str) -> Result<Vec<PartitionMetadata>> {
        let metadata = self.get_topic_metadata(topic).await?;
        Ok(metadata.partitions)
    }

    /// List consumer groups from **every** broker in the cluster.
    ///
    /// In KRaft mode each broker acts as group coordinator only for a subset of
    /// consumer groups. A single `ListGroups` request to the bootstrap broker
    /// therefore misses groups whose coordinator is on a different broker.
    ///
    /// This method sends a `ListGroups` request to each known broker separately
    /// and merges the results, deduplicating by `group_id` (Issue #67 bug 6).
    pub async fn list_groups_all_brokers(
        &self,
    ) -> Result<Vec<super::consumer_groups::ConsumerGroup>> {
        let broker_ids: Vec<i32> = {
            let meta = self.broker_metadata.read().await;
            meta.keys().copied().collect()
        };

        let mut all_groups: Vec<super::consumer_groups::ConsumerGroup> = Vec::new();
        let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();

        for broker_id in broker_ids {
            match self.get_broker_connection(broker_id).await {
                Ok(client) => match super::consumer_groups::list_groups(&client).await {
                    Ok(groups) => {
                        for g in groups {
                            if seen.insert(g.group_id.clone()) {
                                all_groups.push(g);
                            }
                        }
                    }
                    Err(e) => {
                        warn!("list_groups from broker {}: {}", broker_id, e);
                    }
                },
                Err(e) => {
                    warn!(
                        "Failed to connect to broker {} for ListGroups: {}",
                        broker_id, e
                    );
                }
            }
        }

        debug!(
            "list_groups_all_brokers: {} unique groups across {} brokers",
            all_groups.len(),
            self.broker_metadata.read().await.len()
        );
        Ok(all_groups)
    }

    /// List consumer groups from every known broker, failing if any broker
    /// cannot be queried.
    ///
    /// This is intended for safety-critical operations such as restore
    /// cutovers. The best-effort [`Self::list_groups_all_brokers`] variant is
    /// appropriate for inventory and backup discovery, but could otherwise
    /// report an incomplete empty set when a broker is unavailable.
    pub async fn list_groups_all_brokers_strict(
        &self,
    ) -> Result<Vec<super::consumer_groups::ConsumerGroup>> {
        let broker_ids: Vec<i32> = {
            let meta = self.broker_metadata.read().await;
            meta.keys().copied().collect()
        };
        if broker_ids.is_empty() {
            return Err(KafkaError::NoBrokersAvailable.into());
        }

        let mut all_groups = Vec::new();
        let mut seen = std::collections::HashSet::new();
        for broker_id in broker_ids {
            let client = self.get_broker_connection(broker_id).await?;
            for group in super::consumer_groups::list_groups(&client).await? {
                if seen.insert(group.group_id.clone()) {
                    all_groups.push(group);
                }
            }
        }
        Ok(all_groups)
    }

    /// Fetch committed offsets for all consumer groups, routing each `OffsetFetch`
    /// to the broker that coordinates the group.
    ///
    /// In KRaft mode, each broker is group coordinator for a subset of consumer
    /// groups (those whose `__consumer_offsets` partition it leads). Sending
    /// `OffsetFetch` to the bootstrap broker only returns offsets for groups
    /// coordinated by that broker; all others return `NOT_COORDINATOR` (error 16)
    /// or an empty response.
    ///
    /// This method lists groups per-broker and fetches their offsets from the same
    /// broker, ensuring complete coverage across all coordinators.
    ///
    /// Returns a map: `group_id → Vec<CommittedOffset>`.
    pub async fn fetch_group_offsets_all_coordinators(
        &self,
    ) -> Result<std::collections::HashMap<String, Vec<super::consumer_groups::CommittedOffset>>>
    {
        let broker_ids: Vec<i32> = {
            let meta = self.broker_metadata.read().await;
            meta.keys().copied().collect()
        };

        let mut all_offsets: std::collections::HashMap<
            String,
            Vec<super::consumer_groups::CommittedOffset>,
        > = std::collections::HashMap::new();

        for broker_id in broker_ids {
            match self.get_broker_connection(broker_id).await {
                Ok(client) => match super::consumer_groups::list_groups(&client).await {
                    Ok(groups) => {
                        for g in &groups {
                            match super::consumer_groups::fetch_offsets(&client, &g.group_id, None)
                                .await
                            {
                                Ok(offsets) if !offsets.is_empty() => {
                                    all_offsets.insert(g.group_id.clone(), offsets);
                                }
                                Ok(_) => {}
                                Err(e) => {
                                    debug!(
                                        "fetch_offsets for group {} on broker {}: {}",
                                        g.group_id, broker_id, e
                                    );
                                }
                            }
                        }
                    }
                    Err(e) => {
                        warn!(
                            "list_groups from broker {} for offset fetching: {}",
                            broker_id, e
                        );
                    }
                },
                Err(e) => {
                    warn!(
                        "Failed to connect to broker {} for group offsets: {}",
                        broker_id, e
                    );
                }
            }
        }

        debug!(
            "fetch_group_offsets_all_coordinators: {} groups with committed offsets",
            all_offsets.len()
        );
        Ok(all_offsets)
    }

    /// Describe a consumer group through its coordinator.
    ///
    /// DescribeGroups is coordinator-scoped. Sending it to an arbitrary
    /// bootstrap broker can return NOT_COORDINATOR or stale/empty state.
    pub async fn describe_consumer_group(
        &self,
        group_id: &str,
    ) -> Result<super::consumer_groups::ConsumerGroupDescription> {
        let coordinator =
            super::consumer_groups::find_group_coordinator(&self.bootstrap_client, group_id)
                .await?;
        {
            let mut brokers = self.broker_metadata.write().await;
            brokers
                .entry(coordinator.node_id)
                .or_insert_with(|| BrokerMetadata {
                    node_id: coordinator.node_id,
                    host: coordinator.host.clone(),
                    port: coordinator.port,
                    rack: None,
                });
        }
        let client = self.get_broker_connection(coordinator.node_id).await?;
        let mut descriptions =
            super::consumer_groups::describe_groups(&client, &[group_id.to_string()]).await?;
        descriptions.pop().ok_or_else(|| {
            KafkaError::Protocol(format!(
                "DescribeGroups returned no result for group {group_id}"
            ))
            .into()
        })
    }

    /// Commit offsets for a consumer group through that group's coordinator.
    ///
    /// `OffsetCommit` must be sent to the broker that coordinates the group. A
    /// bootstrap broker may not coordinate the group, and committing there can
    /// return coordinator errors in multi-broker KRaft clusters.
    pub async fn commit_group_offsets(
        &self,
        group_id: &str,
        offsets: &[(String, i32, i64, Option<String>)],
    ) -> Result<Vec<(String, i32, i16)>> {
        for attempt in 1..=MAX_COORDINATOR_RETRIES {
            let coordinator = match super::consumer_groups::find_group_coordinator(
                &self.bootstrap_client,
                group_id,
            )
            .await
            {
                Ok(coordinator) => coordinator,
                Err(e)
                    if is_transient_coordinator_error(&e) && attempt < MAX_COORDINATOR_RETRIES =>
                {
                    let backoff = coordinator_backoff(attempt);
                    warn!(
                            "FindCoordinator for group {} returned transient error on attempt {}/{}; retrying after {:?}: {}",
                            group_id, attempt, MAX_COORDINATOR_RETRIES, backoff, e
                        );
                    tokio::time::sleep(backoff).await;
                    continue;
                }
                Err(e) => return Err(e),
            };
            {
                let mut brokers = self.broker_metadata.write().await;
                brokers
                    .entry(coordinator.node_id)
                    .or_insert_with(|| BrokerMetadata {
                        node_id: coordinator.node_id,
                        host: coordinator.host.clone(),
                        port: coordinator.port,
                        rack: None,
                    });
            }

            let client = match self.get_broker_connection(coordinator.node_id).await {
                Ok(client) => client,
                Err(e) => {
                    warn!(
                        "Failed to connect to coordinator broker {} for group {}: {}; refreshing metadata",
                        coordinator.node_id, group_id, e
                    );
                    self.refresh_metadata().await?;
                    self.get_broker_connection(coordinator.node_id).await?
                }
            };

            let results =
                super::consumer_groups::commit_offsets(&client, group_id, offsets).await?;
            if has_transient_coordinator_commit_error(&results) && attempt < MAX_COORDINATOR_RETRIES
            {
                let backoff = coordinator_backoff(attempt);
                warn!(
                    "OffsetCommit for group {} returned transient coordinator error on attempt {}/{}; retrying after {:?}",
                    group_id, attempt, MAX_COORDINATOR_RETRIES, backoff
                );
                self.refresh_metadata().await?;
                tokio::time::sleep(backoff).await;
                continue;
            }

            return Ok(results);
        }

        Err(KafkaError::Timeout(format!(
            "coordinator for group {group_id} was not ready after {MAX_COORDINATOR_RETRIES} attempts"
        ))
        .into())
    }

    /// Delete records from a topic by advancing the log-start-offset to `before_offset`.
    ///
    /// Records with offset < `before_offset` become inaccessible. This empties a topic
    /// without deleting it — safe for Strimzi-managed topics.
    ///
    /// `partitions` is a slice of `(partition_id, before_offset)` pairs.
    pub async fn delete_records(
        &self,
        topic: &str,
        partitions: &[(i32, i64)],
        timeout_ms: i32,
    ) -> Result<()> {
        const MAX_CONNECTION_RETRIES: u32 = 5;
        const MAX_LEADER_RETRIES: u32 = 20;

        if partitions.is_empty() {
            return Ok(());
        }

        let mut connection_attempts = 0;
        let mut leader_attempts = 0;

        loop {
            match self
                .delete_records_internal(topic, partitions, timeout_ms)
                .await
            {
                Ok(()) => return Ok(()),
                Err(e) if is_not_leader_error(&e) && leader_attempts < MAX_LEADER_RETRIES => {
                    leader_attempts += 1;
                    let backoff = Duration::from_millis((250 * leader_attempts as u64).min(2_000));
                    warn!(
                        "NOT_LEADER_FOR_PARTITION during DeleteRecords for topic {} (attempt {}/{}), refreshing metadata after {:?}: {}",
                        topic, leader_attempts, MAX_LEADER_RETRIES, backoff, e
                    );
                    self.refresh_metadata().await?;
                    self.clear_connection_cache().await;
                    tokio::time::sleep(backoff).await;
                }
                Err(e)
                    if is_connection_error(&e) && connection_attempts < MAX_CONNECTION_RETRIES =>
                {
                    connection_attempts += 1;
                    let backoff = Duration::from_millis(500 * connection_attempts as u64);
                    warn!(
                        "Connection error during DeleteRecords for topic {} (attempt {}/{}), retrying after {:?}: {}",
                        topic, connection_attempts, MAX_CONNECTION_RETRIES, backoff, e
                    );
                    self.clear_connection_cache().await;
                    tokio::time::sleep(backoff).await;
                }
                Err(e) => return Err(e),
            }
        }
    }

    async fn delete_records_internal(
        &self,
        topic: &str,
        partitions: &[(i32, i64)],
        timeout_ms: i32,
    ) -> Result<()> {
        let mut partition_leaders = HashMap::new();
        for (partition, _) in partitions {
            let leader_id = self.get_leader(topic, *partition).await?;
            partition_leaders.insert((topic.to_string(), *partition), leader_id);
        }

        let broker_partitions =
            group_partition_offsets_by_leader(topic, partitions, &partition_leaders)?;

        debug!(
            "delete_records: {} partitions for topic {} across {} brokers",
            partitions.len(),
            topic,
            broker_partitions.len()
        );

        for (broker_id, broker_parts) in &broker_partitions {
            let client = self.get_broker_connection(*broker_id).await?;
            super::admin::delete_records(&client, topic, broker_parts, timeout_ms).await?;
        }

        Ok(())
    }
}

fn group_partition_offsets_by_leader(
    topic: &str,
    partitions: &[(i32, i64)],
    partition_leaders: &HashMap<(String, i32), i32>,
) -> Result<HashMap<i32, Vec<(i32, i64)>>> {
    let mut broker_partitions: HashMap<i32, Vec<(i32, i64)>> = HashMap::new();

    for (partition, offset) in partitions {
        let leader_id = partition_leaders
            .get(&(topic.to_string(), *partition))
            .copied()
            .ok_or_else(|| KafkaError::PartitionNotAvailable {
                topic: topic.to_string(),
                partition: *partition,
            })?;

        broker_partitions
            .entry(leader_id)
            .or_default()
            .push((*partition, *offset));
    }

    Ok(broker_partitions)
}

/// Check if an error is a connection-level error that warrants a retry.
///
/// Shares the classifier with `KafkaClient::send_request` (issue #146) so the
/// produce / delete-records retry loops recognise the same set of failures.
fn is_connection_error(error: &crate::Error) -> bool {
    super::connection_error::is_connection_error(error)
}

/// Check if an error is a NOT_LEADER_FOR_PARTITION error (code 6).
fn is_not_leader_error(error: &crate::Error) -> bool {
    match error {
        crate::Error::Kafka(KafkaError::BrokerError { code, .. }) => *code == 6,
        _ => {
            // Also check error message as fallback
            let msg = error.to_string();
            msg.contains("NOT_LEADER") || msg.contains("code 6") || msg.contains("error_code=6")
        }
    }
}

fn is_transient_coordinator_error(error: &crate::Error) -> bool {
    matches!(
        error,
        crate::Error::Kafka(KafkaError::BrokerError {
            code: COORDINATOR_LOAD_IN_PROGRESS | COORDINATOR_NOT_AVAILABLE | NOT_COORDINATOR,
            ..
        })
    )
}

fn has_transient_coordinator_commit_error(results: &[(String, i32, i16)]) -> bool {
    results.iter().any(|(_, _, code)| {
        matches!(
            *code,
            COORDINATOR_LOAD_IN_PROGRESS | COORDINATOR_NOT_AVAILABLE | NOT_COORDINATOR
        )
    })
}

fn coordinator_backoff(attempt: u32) -> Duration {
    Duration::from_millis((250 * attempt as u64).min(2_000))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_is_not_leader_error() {
        let error = crate::Error::Kafka(KafkaError::BrokerError {
            code: 6,
            message: "NOT_LEADER_FOR_PARTITION".to_string(),
        });
        assert!(is_not_leader_error(&error));

        let protocol_error = crate::Error::Kafka(KafkaError::Protocol(
            "DeleteRecords failed: orders[1]: error_code=6 low_watermark=-1".to_string(),
        ));
        assert!(is_not_leader_error(&protocol_error));

        let other_error = crate::Error::Kafka(KafkaError::BrokerError {
            code: 1,
            message: "Some other error".to_string(),
        });
        assert!(!is_not_leader_error(&other_error));
    }

    #[test]
    fn delete_records_partitions_are_grouped_by_leader() {
        let mut leaders = HashMap::new();
        leaders.insert(("orders".to_string(), 0), 1);
        leaders.insert(("orders".to_string(), 1), 2);
        leaders.insert(("orders".to_string(), 2), 1);

        let grouped =
            group_partition_offsets_by_leader("orders", &[(0, 10), (1, 20), (2, 30)], &leaders)
                .expect("partitions should group by leader");

        assert_eq!(grouped.len(), 2);
        assert_eq!(grouped.get(&1), Some(&vec![(0, 10), (2, 30)]));
        assert_eq!(grouped.get(&2), Some(&vec![(1, 20)]));
    }

    #[test]
    fn transient_coordinator_errors_are_retryable() {
        for code in [
            COORDINATOR_LOAD_IN_PROGRESS,
            COORDINATOR_NOT_AVAILABLE,
            NOT_COORDINATOR,
        ] {
            let error = crate::Error::Kafka(KafkaError::BrokerError {
                code,
                message: "coordinator transient".to_string(),
            });
            assert!(is_transient_coordinator_error(&error));
        }

        let fatal = crate::Error::Kafka(KafkaError::BrokerError {
            code: 30,
            message: "group authorization failed".to_string(),
        });
        assert!(!is_transient_coordinator_error(&fatal));
    }

    #[test]
    fn transient_commit_partition_errors_are_retryable() {
        let results = vec![
            ("orders".to_string(), 0, 0),
            ("orders".to_string(), 1, COORDINATOR_NOT_AVAILABLE),
        ];
        assert!(has_transient_coordinator_commit_error(&results));

        let fatal = vec![("orders".to_string(), 0, 30)];
        assert!(!has_transient_coordinator_commit_error(&fatal));
    }
}
