//! Configuration structures for Kafka backup and restore operations.

use serde::{Deserialize, Serialize};
use std::path::PathBuf;

/// Main configuration structure
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    /// Operation mode
    pub mode: Mode,

    /// Unique identifier for this backup
    pub backup_id: String,

    /// Source Kafka cluster configuration (for backup mode)
    #[serde(default)]
    pub source: Option<KafkaConfig>,

    /// Target Kafka cluster configuration (for restore mode)
    #[serde(default)]
    pub target: Option<KafkaConfig>,

    /// Storage configuration (supports S3, Azure, GCS, Filesystem, Memory)
    pub storage: crate::storage::StorageBackendConfig,

    /// Backup-specific options
    #[serde(default)]
    pub backup: Option<BackupOptions>,

    /// Restore-specific options
    #[serde(default)]
    pub restore: Option<RestoreOptions>,

    /// Offset storage configuration
    #[serde(default)]
    pub offset_storage: Option<OffsetStorageConfig>,

    /// Metrics server configuration
    #[serde(default)]
    pub metrics: Option<MetricsConfig>,
}

/// Metrics server configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
#[non_exhaustive]
pub struct MetricsConfig {
    /// Whether metrics server is enabled (default: true)
    #[serde(default = "default_metrics_enabled")]
    pub enabled: bool,

    /// Port for the metrics HTTP server (default: 8080)
    #[serde(default = "default_metrics_port")]
    pub port: u16,

    /// Bind address for the metrics server (default: "0.0.0.0")
    #[serde(default = "default_metrics_bind_address")]
    pub bind_address: String,

    /// Path for the metrics endpoint (default: "/metrics")
    #[serde(default = "default_metrics_path")]
    pub path: String,

    /// How often metrics are recalculated in milliseconds (default: 500)
    #[serde(default = "default_metrics_update_interval_ms")]
    pub update_interval_ms: u64,

    /// Keep serving metrics for this many seconds after a one-shot operation
    /// completes (default: 0).
    #[serde(default = "default_metrics_keep_alive_seconds")]
    pub keep_alive_seconds: u64,

    /// Maximum unique topic/partition label sets to expose (default: 100).
    /// Set to 0 to disable the limit; this can create high-cardinality metrics.
    #[serde(default = "default_max_partition_labels")]
    pub max_partition_labels: usize,
}

impl Default for MetricsConfig {
    fn default() -> Self {
        Self {
            enabled: default_metrics_enabled(),
            port: default_metrics_port(),
            bind_address: default_metrics_bind_address(),
            path: default_metrics_path(),
            update_interval_ms: default_metrics_update_interval_ms(),
            keep_alive_seconds: default_metrics_keep_alive_seconds(),
            max_partition_labels: default_max_partition_labels(),
        }
    }
}

fn default_metrics_enabled() -> bool {
    true
}

fn default_metrics_port() -> u16 {
    8080
}

fn default_metrics_bind_address() -> String {
    "0.0.0.0".to_string()
}

fn default_metrics_path() -> String {
    "/metrics".to_string()
}

fn default_metrics_update_interval_ms() -> u64 {
    500
}

fn default_metrics_keep_alive_seconds() -> u64 {
    0
}

fn default_max_partition_labels() -> usize {
    100
}

/// Offset storage configuration for tracking backup progress
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OffsetStorageConfig {
    /// Storage backend type (sqlite or memory)
    #[serde(default)]
    pub backend: OffsetStorageBackend,

    /// Path to local SQLite database file
    #[serde(default = "default_db_path")]
    pub db_path: PathBuf,

    /// S3 key for syncing offset database
    #[serde(default)]
    pub s3_key: Option<String>,

    /// Sync interval to remote storage in seconds (default: 30)
    #[serde(default = "default_sync_interval_secs")]
    pub sync_interval_secs: u64,
}

impl Default for OffsetStorageConfig {
    fn default() -> Self {
        Self {
            backend: OffsetStorageBackend::default(),
            db_path: default_db_path(),
            s3_key: None,
            sync_interval_secs: default_sync_interval_secs(),
        }
    }
}

fn default_db_path() -> PathBuf {
    PathBuf::from("./offsets.db")
}

/// Offset storage backend type
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum OffsetStorageBackend {
    #[default]
    Sqlite,
    Memory,
}

/// Operation mode
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum Mode {
    Backup,
    Restore,
}

/// Kafka cluster configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct KafkaConfig {
    /// Bootstrap servers
    pub bootstrap_servers: Vec<String>,

    /// Security configuration
    #[serde(default)]
    pub security: SecurityConfig,

    /// Topic selection
    #[serde(default)]
    pub topics: TopicSelection,

    /// TCP connection settings (optional - uses defaults if not specified)
    #[serde(default)]
    pub connection: ConnectionConfig,
}

/// Security configuration for Kafka connections
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct SecurityConfig {
    /// Security protocol
    #[serde(default)]
    pub security_protocol: SecurityProtocol,

    /// SASL mechanism (if using SASL)
    #[serde(default)]
    pub sasl_mechanism: Option<SaslMechanism>,

    /// SASL username
    #[serde(default)]
    pub sasl_username: Option<String>,

    /// SASL password (consider using environment variable interpolation)
    #[serde(default)]
    pub sasl_password: Option<String>,

    /// Path to CA certificate file (for TLS)
    #[serde(default)]
    pub ssl_ca_location: Option<PathBuf>,

    /// Path to client certificate file (for mTLS)
    #[serde(default)]
    pub ssl_certificate_location: Option<PathBuf>,

    /// Path to client key file (for mTLS)
    #[serde(default)]
    pub ssl_key_location: Option<PathBuf>,

    /// Kerberos service name. Must match the broker's
    /// `sasl.kerberos.service.name` (typically `kafka`). Only meaningful
    /// when `sasl_mechanism: GSSAPI`. Defaults to `kafka` at the CLI
    /// wiring layer if unset.
    #[serde(default)]
    pub sasl_kerberos_service_name: Option<String>,

    /// Path to a Kerberos keytab file. If unset, the OS credential cache
    /// (populated via `kinit`) is used. Only meaningful when
    /// `sasl_mechanism: GSSAPI`.
    #[serde(default)]
    pub sasl_keytab_path: Option<PathBuf>,

    /// Path to a Kerberos `krb5.conf`. If unset, the system default is
    /// used. Only meaningful when `sasl_mechanism: GSSAPI`.
    #[serde(default)]
    pub sasl_krb5_config_path: Option<PathBuf>,

    /// Optional pluggable SASL mechanism factory.
    ///
    /// When set, overrides [`sasl_mechanism`] and drives the handshake
    /// through a plugin built per `KafkaClient` (e.g. `OAUTHBEARER` for
    /// MSK IAM, or `GSSAPI` for Kerberos). Not YAML-configurable —
    /// downstream crates inject this programmatically after parsing the
    /// config.
    ///
    /// The factory is invoked once per `KafkaClient` in
    /// `KafkaClient::authenticate`, with the broker endpoint that was
    /// successfully dialed. The `PartitionLeaderRouter` rewrites
    /// `bootstrap_servers` to the advertised per-broker `host:port` before
    /// spawning pooled clients, so stateful mechanisms (GSSAPI) receive the
    /// correct SPN hostname and stateless mechanisms (PLAIN, OAUTHBEARER)
    /// can ignore the argument via [`SharedPluginFactory`].
    ///
    /// [`SharedPluginFactory`]: crate::kafka::SharedPluginFactory
    #[serde(skip)]
    pub sasl_mechanism_plugin_factory: Option<crate::kafka::SaslMechanismPluginFactoryHandle>,
}

/// Security protocol
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum SecurityProtocol {
    #[default]
    Plaintext,
    Ssl,
    SaslPlaintext,
    SaslSsl,
}

/// TCP connection configuration for Kafka broker connections.
///
/// These settings help maintain stable connections to cloud-hosted Kafka services
/// (like Confluent Cloud) that may terminate idle connections.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct ConnectionConfig {
    /// Enable TCP keepalive to prevent idle connection termination (default: true)
    pub tcp_keepalive: bool,

    /// Time in seconds before first keepalive probe is sent (default: 60)
    pub keepalive_time_secs: u64,

    /// Interval in seconds between keepalive probes (default: 20)
    pub keepalive_interval_secs: u64,

    /// Enable TCP_NODELAY to disable Nagle's algorithm (default: true)
    pub tcp_nodelay: bool,

    /// Number of TCP connections to maintain per broker (default: 4).
    ///
    /// Each KafkaClient uses a single TCP connection protected by a mutex.
    /// With a single connection per broker, all concurrent tasks serialize
    /// their requests, and network latency amplifies into a bottleneck.
    /// Multiple connections allow parallel in-flight requests to the same
    /// broker, dramatically improving throughput on high-latency connections.
    #[serde(default = "default_connections_per_broker")]
    pub connections_per_broker: usize,
}

fn default_connections_per_broker() -> usize {
    4
}

impl Default for ConnectionConfig {
    fn default() -> Self {
        Self {
            tcp_keepalive: true,
            keepalive_time_secs: 60,
            keepalive_interval_secs: 20,
            tcp_nodelay: true,
            connections_per_broker: default_connections_per_broker(),
        }
    }
}

/// SASL mechanism
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "SCREAMING-KEBAB-CASE")]
pub enum SaslMechanism {
    Plain,
    ScramSha256,
    ScramSha512,
    /// SASL/GSSAPI (Kerberos). The enum variant is always present, but
    /// constructing a working client requires the `gssapi` cargo feature
    /// on `kafka-backup-cli` (which propagates to `kafka-backup-core`).
    /// CLI builds without the feature surface a clear runtime error when
    /// a config requests `GSSAPI`.
    Gssapi,
}

/// Topic selection configuration
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct TopicSelection {
    /// Topics to include (supports glob patterns)
    #[serde(default)]
    pub include: Vec<String>,

    /// Topics to exclude (supports glob patterns)
    #[serde(default)]
    pub exclude: Vec<String>,
}

/// Legacy storage backend configuration
///
/// **Deprecated**: Use `StorageBackendConfig` from the `storage` module instead.
/// This type is maintained for backward compatibility only.
#[deprecated(
    since = "0.2.0",
    note = "Use crate::storage::StorageBackendConfig instead, which supports Azure, GCS, and more backends"
)]
#[allow(deprecated)] // Allow using deprecated StorageBackendType within this deprecated struct
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StorageConfig {
    /// Storage backend type
    pub backend: StorageBackendType,

    /// Path for filesystem backend
    #[serde(default)]
    pub path: Option<PathBuf>,

    /// S3-compatible storage endpoint
    #[serde(default)]
    pub endpoint: Option<String>,

    /// Bucket name for S3-compatible storage
    #[serde(default)]
    pub bucket: Option<String>,

    /// Access key for S3-compatible storage
    #[serde(default)]
    pub access_key: Option<String>,

    /// Secret key for S3-compatible storage
    #[serde(default)]
    pub secret_key: Option<String>,

    /// Prefix for all storage keys
    #[serde(default)]
    pub prefix: Option<String>,

    /// Region for S3-compatible storage
    #[serde(default)]
    pub region: Option<String>,
}

/// Legacy storage backend type enum
///
/// **Deprecated**: Use `StorageBackendConfig` from the `storage` module instead.
#[deprecated(
    since = "0.2.0",
    note = "Use crate::storage::StorageBackendConfig instead, which supports Azure, GCS, and more backends"
)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum StorageBackendType {
    Filesystem,
    S3,
}

/// Backup-specific options
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BackupOptions {
    /// Maximum segment size in bytes (default: 128MB)
    #[serde(default = "default_segment_max_bytes")]
    pub segment_max_bytes: u64,

    /// Maximum segment time interval in milliseconds (default: 60000)
    #[serde(default = "default_segment_max_interval_ms")]
    pub segment_max_interval_ms: u64,

    /// Compression algorithm
    #[serde(default)]
    pub compression: CompressionType,

    /// Compression level (zstd: 1-22, default: 3)
    #[serde(default = "default_compression_level")]
    pub compression_level: i32,

    /// Starting offset for backup
    #[serde(default)]
    pub start_offset: StartOffset,

    /// Run continuously or one-shot (default: one-shot)
    #[serde(default)]
    pub continuous: bool,

    /// Include internal topics (default: false)
    #[serde(default)]
    pub include_internal_topics: bool,

    /// Internal topics to backup (e.g., __consumer_offsets, __transaction_state)
    #[serde(default)]
    pub internal_topics: Vec<String>,

    /// Checkpoint interval in seconds (default: 5)
    #[serde(default = "default_checkpoint_interval_secs")]
    pub checkpoint_interval_secs: u64,

    /// Sync to remote storage interval in seconds (default: 30)
    #[serde(default = "default_sync_interval_secs")]
    pub sync_interval_secs: u64,

    /// Add offset-tracking headers to every record as it is archived
    /// (Phase 1 of the three-phase restore).
    ///
    /// Adds `x-original-offset` and `x-original-timestamp` (little-endian
    /// `i64`), plus `x-source-cluster` when `source_cluster_id` is set. They
    /// are what makes `consumer_group_strategy: header-based` recovery
    /// possible after a restore, but they also mean an archived record is
    /// not header-for-header identical to the source record.
    ///
    /// **Default: `true`.** Set to `false` for a verbatim archive, or leave
    /// it on and use `restore.strip_offset_headers: true` to drop the
    /// headers at restore time.
    #[serde(default = "default_include_offset_headers")]
    pub include_offset_headers: bool,

    /// Source cluster identifier for x-source-cluster header
    /// Useful for tracking which cluster the backup originated from
    #[serde(default)]
    pub source_cluster_id: Option<String>,

    /// Snapshot mode: capture current high watermarks at backup start and stop
    /// when all partitions have reached their target offsets.
    ///
    /// This provides consistent "point-in-time" snapshots for DR backups.
    /// When enabled:
    /// 1. At startup, captures high watermarks for ALL partitions
    /// 2. Each partition backs up until it reaches its snapshot target
    /// 3. Backup exits cleanly when all partitions are caught up
    ///
    /// Incompatible with `continuous: true` mode.
    /// Default: false
    #[serde(default)]
    pub stop_at_current_offsets: bool,

    /// Maximum concurrent partitions to backup in parallel.
    ///
    /// Limits resource usage (CPU, memory, network, storage I/O) by controlling
    /// how many partitions are processed simultaneously. Higher values increase
    /// throughput but may cause resource contention.
    ///
    /// Default: 8
    #[serde(default = "default_backup_max_concurrent_partitions")]
    pub max_concurrent_partitions: usize,

    /// Poll interval in milliseconds for continuous backup mode.
    ///
    /// In continuous mode, after each complete pass through all partitions,
    /// the backup waits this long before starting the next pass.
    /// Lower values reduce lag but increase CPU usage.
    ///
    /// Default: 100ms (was hardcoded to 1000ms)
    #[serde(default = "default_poll_interval_ms")]
    pub poll_interval_ms: u64,

    /// Snapshot consumer group offsets to storage after each backup cycle.
    ///
    /// When `true`, the backup engine queries every broker for consumer groups,
    /// fetches their committed offsets, filters to groups with offsets on
    /// backed-up topics, and writes `{backup_id}/consumer-groups-snapshot.json`.
    ///
    /// This file is consumed by `auto_consumer_groups: true` at restore time.
    /// Default: `false` — opt in explicitly to avoid unexpected overhead.
    #[serde(default)]
    pub consumer_group_snapshot: bool,

    /// Maximum bytes requested per Kafka Fetch request.
    ///
    /// When unset, fetches request `min(segment_max_bytes, 16MB)`.
    /// Values are clamped to the Kafka protocol's i32 range.
    #[serde(default)]
    pub fetch_max_bytes: Option<u64>,

    /// Maximum records per segment before rotation.
    ///
    /// When unset, segments rotate on `segment_max_bytes` /
    /// `segment_max_interval_ms` only.
    #[serde(default)]
    pub segment_max_records: Option<u64>,

    /// Capture explicit, mutable topic-level configuration overrides in the
    /// backup manifest. Sensitive, read-only, and broker-default values are
    /// never persisted.
    #[serde(default = "default_capture_topic_configs")]
    pub capture_topic_configs: bool,

    /// Fail the backup when topic configuration cannot be captured. This is
    /// recommended for compliance and disaster-recovery jobs.
    #[serde(default)]
    pub require_topic_configs: bool,

    /// Retention for this backup set: prune aged/oversized segments at the
    /// end of each backup cycle (see `kafka-backup prune` for the on-demand
    /// form). Off by default. Bucket lifecycle rules must NOT be used on an
    /// incremental set — see the storage guide.
    #[serde(default)]
    pub retention: Option<RetentionOptions>,
}

/// Retention policy for a backup set (issue #169).
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct RetentionOptions {
    /// Prune segments older than this human-readable duration (`30d`, `12h`,
    /// `1d12h`, …). Deviates from the `_secs` convention deliberately:
    /// `2592000` is not a number a reviewer can read, and the operator's
    /// `retention.maxAge` already uses this grammar.
    #[serde(default)]
    pub max_age: Option<String>,

    /// After the age pass, keep pruning oldest-first until the set's total
    /// compressed size fits under this many bytes (compressed sizes).
    #[serde(default)]
    pub max_total_bytes: Option<u64>,

    /// Never prune a partition below this many newest segments.
    #[serde(default = "default_keep_segments")]
    pub keep_segments: usize,
}

fn default_keep_segments() -> usize {
    1
}

impl RetentionOptions {
    /// Convert to prune criteria, resolving `max_age` against "now".
    pub fn to_criteria(&self) -> crate::Result<crate::backup::prune::PruneCriteria> {
        let older_than = match &self.max_age {
            Some(raw) => {
                let d = crate::util::parse_duration(raw)?;
                Some(chrono::Utc::now().timestamp_millis() - d.as_millis() as i64)
            }
            None => None,
        };
        Ok(crate::backup::prune::PruneCriteria {
            older_than,
            max_total_bytes: self.max_total_bytes,
            keep_segments: self.keep_segments.max(1),
        })
    }

    pub fn validate(&self) -> crate::Result<()> {
        if let Some(raw) = &self.max_age {
            crate::util::parse_duration(raw)?;
        }
        if self.max_age.is_none() && self.max_total_bytes.is_none() {
            return Err(crate::Error::Config(
                "backup.retention requires max_age and/or max_total_bytes".to_string(),
            ));
        }
        if self.keep_segments == 0 {
            return Err(crate::Error::Config(
                "backup.retention.keep_segments must be >= 1".to_string(),
            ));
        }
        Ok(())
    }
}

fn default_capture_topic_configs() -> bool {
    true
}

fn default_include_offset_headers() -> bool {
    true
}

fn default_backup_max_concurrent_partitions() -> usize {
    8 // Balance between parallelism and resource usage
}

fn default_poll_interval_ms() -> u64 {
    100 // 100ms - much lower than old hardcoded 1000ms for better lag reduction
}

impl Default for BackupOptions {
    fn default() -> Self {
        Self {
            segment_max_bytes: default_segment_max_bytes(),
            segment_max_interval_ms: default_segment_max_interval_ms(),
            compression: CompressionType::default(),
            compression_level: default_compression_level(),
            start_offset: StartOffset::default(),
            continuous: false,
            include_internal_topics: false,
            internal_topics: Vec::new(),
            checkpoint_interval_secs: default_checkpoint_interval_secs(),
            sync_interval_secs: default_sync_interval_secs(),
            include_offset_headers: default_include_offset_headers(),
            source_cluster_id: None,
            stop_at_current_offsets: false,
            max_concurrent_partitions: default_backup_max_concurrent_partitions(),
            poll_interval_ms: default_poll_interval_ms(),
            consumer_group_snapshot: false,
            fetch_max_bytes: None,
            segment_max_records: None,
            capture_topic_configs: default_capture_topic_configs(),
            require_topic_configs: false,
            retention: None,
        }
    }
}

fn default_segment_max_bytes() -> u64 {
    128 * 1024 * 1024 // 128MB
}

fn default_segment_max_interval_ms() -> u64 {
    60_000 // 60 seconds
}

fn default_compression_level() -> i32 {
    3 // zstd default
}

fn default_checkpoint_interval_secs() -> u64 {
    5 // 5 seconds
}

fn default_sync_interval_secs() -> u64 {
    30 // 30 seconds
}

/// Compression type
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum CompressionType {
    None,
    #[default]
    Zstd,
    Lz4,
}

/// Starting offset for backup
#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum StartOffset {
    #[default]
    Earliest,
    Latest,
    /// Specific offset per partition (topic -> partition -> offset)
    #[serde(rename = "specific")]
    Specific(std::collections::HashMap<String, std::collections::HashMap<i32, i64>>),
}

/// Repartitioning strategy for restoring to a different partition count
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum RepartitioningStrategy {
    /// Murmur2 hash partitioning (Kafka default): murmur2(key) % N.
    /// Records with a null key use round-robin. Empty keys (`[]`) ARE hashed.
    #[default]
    Murmur2,
    /// Round-robin for all records regardless of key.
    Automatic,
}

impl std::fmt::Display for RepartitioningStrategy {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Murmur2 => write!(f, "murmur2"),
            Self::Automatic => write!(f, "automatic"),
        }
    }
}

/// Per-topic repartitioning configuration
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TopicRepartitioning {
    /// Partitioning strategy to use
    #[serde(default)]
    pub strategy: RepartitioningStrategy,
    /// Number of partitions in the target topic (must be > 0)
    pub target_partitions: i32,
}

/// Consumer offset handling strategy during restore
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum OffsetStrategy {
    /// Skip offset handling entirely (just restore data)
    #[default]
    Skip,
    /// Store original offset in message header (x-original-offset, x-original-timestamp)
    HeaderBased,
    /// Use timestamp-based seeking in target cluster
    TimestampBased,
    /// Scan target cluster and auto-map offsets
    ClusterScan,
    /// Report mapping only, require manual reset
    Manual,
}

/// Policy for restoring topic configuration to topics that already exist.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExistingTopicConfigPolicy {
    /// Report configuration drift but do not mutate an existing topic.
    #[default]
    ValidateOnly,
    /// Apply source topic overrides to an existing topic.
    Apply,
    /// Fail restore when an existing topic differs from the backup.
    Fail,
}

/// Restore-specific options
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RestoreOptions {
    /// Time window start (epoch milliseconds) for PITR
    #[serde(default)]
    pub time_window_start: Option<i64>,

    /// Time window end (epoch milliseconds) for PITR
    #[serde(default)]
    pub time_window_end: Option<i64>,

    /// Source partitions to restore (if filtering specific partitions)
    #[serde(default)]
    pub source_partitions: Option<Vec<i32>>,

    /// Partition mapping (source_partition -> target_partition)
    #[serde(default)]
    pub partition_mapping: std::collections::HashMap<i32, i32>,

    /// Topic mapping (original -> target)
    #[serde(default)]
    pub topic_mapping: std::collections::HashMap<String, String>,

    /// Consumer group offset handling strategy
    #[serde(default)]
    pub consumer_group_strategy: OffsetStrategy,

    /// Dry-run mode - validate without writing to target cluster
    #[serde(default)]
    pub dry_run: bool,

    /// Add `x-original-offset`, `x-original-timestamp` and
    /// `x-source-partition` headers to every record as it is produced to
    /// the target cluster. Also implied by `consumer_group_strategy:
    /// header-based`. Default: `false`.
    #[serde(default)]
    pub include_original_offset_header: bool,

    /// Remove the headers kafka-backup adds (`x-original-offset`,
    /// `x-original-timestamp`, `x-source-cluster`, `x-source-partition`)
    /// from archived records before producing them, so a restored record
    /// carries exactly the headers the source record had.
    ///
    /// Use this to restore an archive taken with the default
    /// `backup.include_offset_headers: true` header-for-header identical to
    /// the source. Offset mapping is unaffected: the source offset is stored
    /// natively in the segment, not only in the header. If
    /// `include_original_offset_header` / `header-based` is also on, the
    /// headers are stripped first and fresh ones injected.
    ///
    /// Default: `false`.
    #[serde(default)]
    pub strip_offset_headers: bool,

    /// Rate limit in records per second
    #[serde(default)]
    pub rate_limit_records_per_sec: Option<u64>,

    /// Rate limit in bytes per second
    #[serde(default)]
    pub rate_limit_bytes_per_sec: Option<u64>,

    /// Maximum concurrent partitions to restore in parallel
    #[serde(default = "default_max_concurrent_partitions")]
    pub max_concurrent_partitions: usize,

    /// Batch size for producing to target cluster (number of records)
    #[serde(default = "default_produce_batch_size")]
    pub produce_batch_size: usize,

    /// Producer acknowledgement level sent to the broker.
    ///
    /// - `-1` (default): wait for all in-sync replicas — highest durability.
    /// - `1`: wait for the partition leader only — lower latency on clusters with
    ///   lagging replicas at the cost of reduced durability.
    /// - `0`: fire-and-forget — fastest but no delivery guarantee.
    ///
    /// Change from `-1` only when restore speed is critical and the cluster
    /// replication factor is known to be > 1 (Issue #67 bug 9).
    #[serde(default = "default_produce_acks")]
    pub produce_acks: i16,

    /// Broker-side produce timeout in milliseconds (default: 30 000).
    ///
    /// The broker waits up to this duration for the required acks before
    /// returning REQUEST_TIMED_OUT. The client-side socket timeout must stay
    /// above this value so slow replicated writes can return broker errors
    /// instead of being misclassified as transport failures.
    #[serde(default = "default_produce_timeout_ms")]
    pub produce_timeout_ms: i32,

    /// Checkpoint state file path for resumable restores
    #[serde(default)]
    pub checkpoint_state: Option<std::path::PathBuf>,

    /// Checkpoint interval in seconds
    #[serde(default = "default_restore_checkpoint_interval_secs")]
    pub checkpoint_interval_secs: u64,

    /// Consumer groups to reset offsets for (requires reset_consumer_offsets)
    #[serde(default)]
    pub consumer_groups: Vec<String>,

    /// Whether to reset consumer group offsets (dangerous, requires explicit opt-in)
    #[serde(default)]
    pub reset_consumer_offsets: bool,

    /// Output file for offset mapping report
    #[serde(default)]
    pub offset_report: Option<std::path::PathBuf>,

    /// Automatically create missing topics before restore
    /// Default: false (safe default - won't create topics unexpectedly)
    #[serde(default)]
    pub create_topics: bool,

    /// Replication factor for auto-created topics
    /// Default: None (use broker default, typically 1)
    /// Set to -1 to explicitly use broker default
    #[serde(default)]
    pub default_replication_factor: Option<i16>,

    /// Per-topic repartitioning configuration, keyed by TARGET topic name.
    /// When set, records are re-partitioned on the fly using the configured strategy
    /// instead of the default 1:1 partition mapping.
    /// Mutually exclusive with `partition_mapping`.
    #[serde(default)]
    pub repartitioning: std::collections::HashMap<String, TopicRepartitioning>,

    /// Purge target topics before restoring by advancing each partition's
    /// log-start-offset to its current end-offset via the `DeleteRecords` API.
    ///
    /// This makes the topic appear empty without deleting it — required for
    /// Strimzi-managed topics which cannot be deleted and recreated via the
    /// standard Kafka admin API.
    ///
    /// **Irreversible.** Default: `false`.
    #[serde(default)]
    pub purge_topics: bool,

    /// Automatically load the consumer-groups snapshot written by the backup
    /// engine (or the `snapshot-groups` command) and use it to populate
    /// `consumer_groups` before starting the restore.
    ///
    /// The snapshot is read from `{backup_id}/consumer-groups-snapshot.json`
    /// in the configured storage backend. When the file is absent the option
    /// is silently ignored and the restore continues without offset reset.
    ///
    /// Setting this also enables `reset_consumer_offsets` automatically.
    /// Default: `false`.
    #[serde(default)]
    pub auto_consumer_groups: bool,

    /// Restore captured topic-level configuration overrides. Newly created
    /// topics always receive the captured overrides when this is enabled.
    #[serde(default = "default_restore_topic_configs")]
    pub restore_topic_configs: bool,

    /// How to handle captured configuration for target topics that existed
    /// before the restore started.
    #[serde(default)]
    pub existing_topic_config_policy: ExistingTopicConfigPolicy,

    /// Per-target-topic configuration overrides. These take precedence over
    /// values captured from the source manifest.
    #[serde(default)]
    pub topic_config_overrides:
        std::collections::HashMap<String, std::collections::BTreeMap<String, String>>,

    /// Rewrite Confluent wire-format schema IDs in record keys and values.
    /// This is populated by the enterprise Schema Registry restore before the
    /// Kafka data phase; it is inert unless explicitly enabled.
    #[serde(default)]
    pub rewrite_schema_ids: bool,

    /// Source-to-target Schema Registry ID mapping used by
    /// `rewrite_schema_ids`. Map keys are the IDs encoded after the Confluent
    /// magic byte and values are the IDs registered in the target registry.
    #[serde(default)]
    pub schema_id_mapping: std::collections::HashMap<i32, i32>,

    /// Phase 1 header preflight behaviour.
    ///
    /// - `auto` (default): scan the backup for tracking-header coverage when
    ///   consumer-offset recovery is requested, and fail before any target
    ///   mutation if required metadata is missing.
    /// - `full`: always scan, even when offset recovery is not requested
    ///   (findings are warnings in that case).
    /// - `skip`: never scan. Explicit escape hatch; an offset-recovery
    ///   request proceeds UNVERIFIED with a loud warning.
    #[serde(default)]
    pub header_preflight: HeaderPreflightMode,

    /// Set by orchestrators (e.g. three-phase restore) that already ran the
    /// header preflight, so the restore engine does not scan the backup a
    /// second time. Not configurable from YAML.
    #[serde(skip)]
    pub header_preflight_external: bool,

    /// During `validate-restore` / dry-run, HEAD every segment in the
    /// selected time window instead of only the oldest per partition (the
    /// default canary, which catches lifecycle-rule expiry at
    /// one-request-per-partition cost). Full sweeps can take a long time on
    /// large archives. Default: `false`.
    #[serde(default)]
    pub dry_run_check_segments: bool,

    /// Programmatic per-record filter (Keep / Drop / Tombstone), consulted on
    /// every restore path after time-window filtering. Set by code — e.g. an
    /// embedding application or a commercial distribution — never from YAML.
    /// See [`crate::restore::filter`].
    #[serde(skip)]
    pub record_filter: Option<crate::restore::filter::RecordFilterHandle>,

    /// Opaque fingerprint of the configured record filter (e.g. a digest of
    /// its rule set), folded into the restore checkpoint's `config_hash` so a
    /// resumed restore notices when the filter changed. Set by whoever sets
    /// `record_filter`; not configurable from YAML.
    #[serde(skip)]
    pub record_filter_fingerprint: Option<String>,
}

/// Controls the Phase 1 header preflight scan (see issue #137).
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum HeaderPreflightMode {
    /// Scan when consumer-offset recovery is requested; strict failure.
    #[default]
    Auto,
    /// Always scan; strict only when offset recovery is requested.
    Full,
    /// Never scan (explicit operator override; loud warning).
    Skip,
}

impl std::fmt::Display for HeaderPreflightMode {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(match self {
            Self::Auto => "auto",
            Self::Full => "full",
            Self::Skip => "skip",
        })
    }
}

fn default_restore_topic_configs() -> bool {
    true
}

/// Hand-written `Default` so that `RestoreOptions::default()` in Rust code
/// matches the serde defaults used when deserialising from YAML — the derived
/// `Default` would give `0` for all numeric fields, which breaks callers that
/// do `RestoreOptions { field: value, ..RestoreOptions::default() }`.
impl Default for RestoreOptions {
    fn default() -> Self {
        Self {
            time_window_start: None,
            time_window_end: None,
            source_partitions: None,
            partition_mapping: Default::default(),
            topic_mapping: Default::default(),
            consumer_group_strategy: OffsetStrategy::default(),
            dry_run: false,
            include_original_offset_header: false,
            strip_offset_headers: false,
            rate_limit_records_per_sec: None,
            rate_limit_bytes_per_sec: None,
            max_concurrent_partitions: default_max_concurrent_partitions(),
            produce_batch_size: default_produce_batch_size(),
            produce_acks: default_produce_acks(),
            produce_timeout_ms: default_produce_timeout_ms(),
            checkpoint_state: None,
            checkpoint_interval_secs: default_restore_checkpoint_interval_secs(),
            consumer_groups: Vec::new(),
            reset_consumer_offsets: false,
            offset_report: None,
            create_topics: false,
            default_replication_factor: None,
            repartitioning: Default::default(),
            purge_topics: false,
            auto_consumer_groups: false,
            restore_topic_configs: default_restore_topic_configs(),
            existing_topic_config_policy: ExistingTopicConfigPolicy::default(),
            topic_config_overrides: Default::default(),
            rewrite_schema_ids: false,
            schema_id_mapping: Default::default(),
            header_preflight: HeaderPreflightMode::default(),
            header_preflight_external: false,
            dry_run_check_segments: false,
            record_filter: None,
            record_filter_fingerprint: None,
        }
    }
}

fn default_max_concurrent_partitions() -> usize {
    4
}

fn default_produce_batch_size() -> usize {
    1000
}

fn default_produce_acks() -> i16 {
    -1 // acks=all — highest durability (safe default)
}

fn default_produce_timeout_ms() -> i32 {
    30_000 // 30 seconds, matching the previous hardcoded value
}

/// Public accessor for integration tests that assert the default acks value.
pub fn default_produce_acks_pub() -> i16 {
    default_produce_acks()
}

/// Public accessor for integration tests that assert the default timeout value.
pub fn default_produce_timeout_ms_pub() -> i32 {
    default_produce_timeout_ms()
}

fn default_restore_checkpoint_interval_secs() -> u64 {
    60
}

impl Config {
    /// Parse a YAML config, collecting the paths of any keys that were
    /// ignored during deserialization.
    ///
    /// The config structs do not reject unknown fields, so a typo like
    /// `fetch_max_bytez` would otherwise be silently dropped and the
    /// operator-provided or hand-written option would simply not apply.
    /// Callers should surface the returned paths as warnings.
    pub fn from_yaml_with_warnings(yaml: &str) -> crate::Result<(Self, Vec<String>)> {
        let mut ignored = Vec::new();
        let deserializer = serde_yaml::Deserializer::from_str(yaml);
        let config: Config =
            serde_ignored::deserialize(deserializer, |path| ignored.push(path.to_string()))
                .map_err(|e| crate::Error::Config(format!("Failed to parse config: {e}")))?;

        let ignored = ignored
            .into_iter()
            // serde_ignored renders Option/enum layers as `?` segments
            // (e.g. `backup.?.key`); drop them for readable key paths.
            .map(|path| {
                path.split('.')
                    .filter(|segment| *segment != "?")
                    .collect::<Vec<_>>()
                    .join(".")
            })
            // The documented `logging` section is applied by the CLI layer
            // (RUST_LOG / -v), not deserialized into this struct — not a typo.
            .filter(|path| path != "logging" && !path.starts_with("logging."))
            .collect();

        Ok((config, ignored))
    }

    /// Validate the configuration
    pub fn validate(&self) -> crate::Result<()> {
        match self.mode {
            Mode::Backup => {
                if self.source.is_none() {
                    return Err(crate::Error::Config(
                        "Source configuration is required for backup mode".to_string(),
                    ));
                }

                // Validate backup-specific options
                if let Some(backup) = &self.backup {
                    backup.validate()?;
                }
            }
            Mode::Restore => {
                if self.target.is_none() {
                    return Err(crate::Error::Config(
                        "Target configuration is required for restore mode".to_string(),
                    ));
                }

                // Validate restore-specific options
                if let Some(restore) = &self.restore {
                    restore.validate()?;
                }
            }
        }

        // Storage config validation is handled by StorageBackendConfig's typed enum
        // Required fields are non-Optional in each variant, so invalid configs
        // fail at deserialization time rather than runtime validation

        Ok(())
    }
}

impl BackupOptions {
    /// Validate backup options
    pub fn validate(&self) -> crate::Result<()> {
        // stop_at_current_offsets is incompatible with continuous mode
        if self.stop_at_current_offsets && self.continuous {
            return Err(crate::Error::Config(
                "stop_at_current_offsets cannot be used with continuous mode. \
                 Use stop_at_current_offsets for snapshot backups (catch up and exit), \
                 or continuous for streaming replication (run forever)."
                    .to_string(),
            ));
        }

        // Validate compression level
        if self.compression_level < 1 || self.compression_level > 22 {
            return Err(crate::Error::Config(format!(
                "compression_level must be between 1 and 22, got {}",
                self.compression_level
            )));
        }

        // Validate max_concurrent_partitions
        if self.max_concurrent_partitions == 0 {
            return Err(crate::Error::Config(
                "max_concurrent_partitions must be > 0".to_string(),
            ));
        }

        if let Some(retention) = &self.retention {
            retention.validate()?;
        }

        Ok(())
    }
}

impl RestoreOptions {
    /// Validate restore options
    pub fn validate(&self) -> crate::Result<()> {
        // Check time window sanity
        if let (Some(from), Some(to)) = (self.time_window_start, self.time_window_end) {
            if from > to {
                return Err(crate::Error::Config(format!(
                    "time_window_start ({}) > time_window_end ({})",
                    from, to
                )));
            }
        }

        // Validate partition mapping
        for (src, dst) in &self.partition_mapping {
            if *src < 0 || *dst < 0 {
                return Err(crate::Error::Config(format!(
                    "Invalid partition number in mapping: {} -> {}",
                    src, dst
                )));
            }
        }

        // Validate source partitions
        if let Some(partitions) = &self.source_partitions {
            for p in partitions {
                if *p < 0 {
                    return Err(crate::Error::Config(format!(
                        "Invalid source partition number: {}",
                        p
                    )));
                }
            }
        }

        // Validate rate limits
        if let Some(rate) = self.rate_limit_records_per_sec {
            if rate == 0 {
                return Err(crate::Error::Config(
                    "rate_limit_records_per_sec must be > 0".to_string(),
                ));
            }
        }

        if let Some(rate) = self.rate_limit_bytes_per_sec {
            if rate == 0 {
                return Err(crate::Error::Config(
                    "rate_limit_bytes_per_sec must be > 0".to_string(),
                ));
            }
        }

        // Validate concurrent partitions
        if self.max_concurrent_partitions == 0 {
            return Err(crate::Error::Config(
                "max_concurrent_partitions must be > 0".to_string(),
            ));
        }

        // Validate batch size
        if self.produce_batch_size == 0 {
            return Err(crate::Error::Config(
                "produce_batch_size must be > 0".to_string(),
            ));
        }

        // Validate consumer group offset reset
        if self.reset_consumer_offsets
            && self.consumer_groups.is_empty()
            && !self.auto_consumer_groups
        {
            return Err(crate::Error::Config(
                "consumer_groups must be specified when reset_consumer_offsets is true".to_string(),
            ));
        }

        // Validate repartitioning
        for (topic, repart) in &self.repartitioning {
            if repart.target_partitions <= 0 {
                return Err(crate::Error::Config(format!(
                    "repartitioning target_partitions must be > 0 for topic '{}', got {}",
                    topic, repart.target_partitions
                )));
            }
        }

        // Note: partition_mapping and repartitioning can coexist — repartitioning
        // takes precedence for topics that have it configured, while partition_mapping
        // applies to the remaining topics. The engine handles this via early-return
        // branching in restore_topic().

        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn backup_options_parse_fetch_max_bytes_and_segment_max_records() {
        let yaml = "fetch_max_bytes: 16777216\nsegment_max_records: 2000000\n";
        let opts: BackupOptions = serde_yaml::from_str(yaml).unwrap();
        assert_eq!(opts.fetch_max_bytes, Some(16777216));
        assert_eq!(opts.segment_max_records, Some(2_000_000));

        let defaults = BackupOptions::default();
        assert_eq!(defaults.fetch_max_bytes, None);
        assert_eq!(defaults.segment_max_records, None);
    }

    #[test]
    fn pre_v0_16_config_parses_unchanged_with_no_warnings() {
        // A config written for older versions (no v0.16.0 keys) must parse
        // with identical semantics and produce zero warnings.
        let yaml = r#"
mode: backup
backup_id: compat-test
source:
  bootstrap_servers:
    - localhost:9092
storage:
  backend: filesystem
  path: /tmp/compat-test
backup:
  compression: zstd
  segment_max_bytes: 134217728
  stop_at_current_offsets: true
"#;
        let (config, warnings) = Config::from_yaml_with_warnings(yaml).unwrap();
        assert!(
            warnings.is_empty(),
            "expected no warnings, got {warnings:?}"
        );
        let opts = config.backup.unwrap();
        assert_eq!(opts.fetch_max_bytes, None);
        assert_eq!(opts.segment_max_records, None);
        assert_eq!(opts.segment_max_bytes, 134217728);
        assert!(opts.stop_at_current_offsets);
    }

    #[test]
    fn config_from_yaml_with_warnings_reports_unknown_keys() {
        let yaml = r#"
mode: backup
backup_id: warn-test
source:
  bootstrap_servers:
    - localhost:9092
storage:
  backend: filesystem
  path: /tmp/warn-test
backup:
  segment_max_bytes: 1048576
  fetch_max_bytez: 123
not_a_real_section:
  foo: 1
"#;
        let (config, warnings) = Config::from_yaml_with_warnings(yaml).unwrap();
        assert_eq!(config.backup_id, "warn-test");
        assert!(
            warnings.iter().any(|w| w == "backup.fetch_max_bytez"),
            "expected a clean `backup.fetch_max_bytez` path (no `?` segments), got {warnings:?}"
        );
        assert!(
            warnings.iter().any(|w| w.contains("not_a_real_section")),
            "expected a warning for not_a_real_section, got {warnings:?}"
        );
    }

    #[test]
    fn config_from_yaml_with_warnings_is_quiet_for_known_keys() {
        let yaml = r#"
mode: backup
backup_id: quiet-test
source:
  bootstrap_servers:
    - localhost:9092
storage:
  backend: filesystem
  path: /tmp/quiet-test
backup:
  segment_max_bytes: 1048576
  fetch_max_bytes: 16777216
  segment_max_records: 2000000
logging:
  level: debug
  format: text
"#;
        let (_, warnings) = Config::from_yaml_with_warnings(yaml).unwrap();
        assert!(
            warnings.is_empty(),
            "expected no warnings, got {warnings:?}"
        );
    }

    /// Issue #154: the backup-side default is `true` and was undocumented.
    /// This pins the contract so a change to it is a deliberate one.
    #[test]
    fn backup_include_offset_headers_defaults_to_true() {
        assert!(BackupOptions::default().include_offset_headers);
        let yaml = r#"
mode: backup
backup_id: defaults
source:
  bootstrap_servers: [localhost:9092]
storage:
  backend: filesystem
  path: /tmp/defaults
backup:
  compression: zstd
"#;
        let (config, _) = Config::from_yaml_with_warnings(yaml).unwrap();
        assert!(config.backup.unwrap().include_offset_headers);
    }

    #[test]
    fn restore_strip_offset_headers_defaults_to_false_and_parses() {
        assert!(!RestoreOptions::default().strip_offset_headers);
        let yaml = r#"
mode: restore
backup_id: strip
target:
  bootstrap_servers: [localhost:9092]
storage:
  backend: filesystem
  path: /tmp/strip
restore:
  strip_offset_headers: true
  consumer_group_strategy: skip
"#;
        let (config, warnings) = Config::from_yaml_with_warnings(yaml).unwrap();
        assert!(warnings.is_empty(), "{warnings:?}");
        let restore = config.restore.unwrap();
        assert!(restore.strip_offset_headers);
        assert!(!restore.include_original_offset_header);
        assert_eq!(restore.consumer_group_strategy, OffsetStrategy::Skip);
    }

    #[test]
    fn test_connection_config_defaults() {
        let config = ConnectionConfig::default();
        assert!(config.tcp_keepalive);
        assert_eq!(config.keepalive_time_secs, 60);
        assert_eq!(config.keepalive_interval_secs, 20);
        assert!(config.tcp_nodelay);
    }

    #[test]
    fn test_kafka_config_connection_defaults() {
        // Test that KafkaConfig uses ConnectionConfig::default() when not specified
        let yaml = r#"
bootstrap_servers:
  - "localhost:9092"
"#;
        let config: KafkaConfig = serde_yaml::from_str(yaml).unwrap();
        assert!(config.connection.tcp_keepalive);
        assert_eq!(config.connection.keepalive_time_secs, 60);
        assert_eq!(config.connection.keepalive_interval_secs, 20);
        assert!(config.connection.tcp_nodelay);
    }

    #[test]
    fn test_metrics_config_defaults() {
        let config = MetricsConfig::default();
        assert_eq!(config.keep_alive_seconds, 0);
    }

    #[test]
    fn test_metrics_config_keep_alive_yaml() {
        let yaml = r#"
enabled: true
port: 8080
bind_address: "0.0.0.0"
path: "/metrics"
keep_alive_seconds: 90
"#;
        let config: MetricsConfig = serde_yaml::from_str(yaml).unwrap();
        assert_eq!(config.keep_alive_seconds, 90);
    }

    #[test]
    fn test_security_config_serde_skips_plugin_factory_field() {
        // `sasl_mechanism_plugin_factory` is `#[serde(skip)]` —
        // programmatic only. Regressions would leak a non-serializable
        // trait object into YAML and break config round-tripping. This
        // test pins it.
        use std::sync::Arc;

        #[derive(Debug)]
        struct NoopPlugin;
        #[async_trait::async_trait]
        impl crate::kafka::SaslMechanismPlugin for NoopPlugin {
            fn mechanism_name(&self) -> &str {
                "NOOP"
            }
            async fn initial_payload(&self) -> Result<Vec<u8>, crate::kafka::SaslPluginError> {
                Ok(vec![])
            }
        }

        let plugin: crate::kafka::SaslMechanismPluginHandle = Arc::new(NoopPlugin);
        let factory = crate::kafka::SharedPluginFactory::new(plugin).into_handle();

        let cfg = SecurityConfig {
            security_protocol: SecurityProtocol::SaslPlaintext,
            sasl_mechanism_plugin_factory: Some(factory),
            ..Default::default()
        };
        let yaml = serde_yaml::to_string(&cfg).expect("serialize security config");
        assert!(
            !yaml.contains("sasl_mechanism_plugin_factory"),
            "serde(skip) must keep the factory field out of YAML; got:\n{yaml}"
        );

        // Round-trip: deserialization into a config without the field
        // yields `None` — we never try to rehydrate a trait object.
        let back: SecurityConfig = serde_yaml::from_str(&yaml).expect("deserialize");
        assert!(back.sasl_mechanism_plugin_factory.is_none());
    }

    #[test]
    fn test_security_config_gssapi_serde_roundtrip() {
        // Pins the YAML spelling `GSSAPI` (SCREAMING-KEBAB-CASE) and that
        // all three Kerberos path fields deserialize into Options.
        let yaml = r#"
security_protocol: SASL_PLAINTEXT
sasl_mechanism: GSSAPI
sasl_kerberos_service_name: kafka
sasl_keytab_path: /etc/kafka/client.keytab
sasl_krb5_config_path: /etc/krb5.conf
"#;
        let cfg: SecurityConfig = serde_yaml::from_str(yaml).expect("deserialize GSSAPI config");
        assert_eq!(cfg.security_protocol, SecurityProtocol::SaslPlaintext);
        assert_eq!(cfg.sasl_mechanism, Some(SaslMechanism::Gssapi));
        assert_eq!(cfg.sasl_kerberos_service_name.as_deref(), Some("kafka"));
        assert_eq!(
            cfg.sasl_keytab_path.as_deref(),
            Some(std::path::Path::new("/etc/kafka/client.keytab"))
        );
        assert_eq!(
            cfg.sasl_krb5_config_path.as_deref(),
            Some(std::path::Path::new("/etc/krb5.conf"))
        );

        // Round-trip back to YAML — variant must spell as `GSSAPI`, not
        // `Gssapi` or `GSS-API`.
        let back = serde_yaml::to_string(&cfg).expect("serialize");
        assert!(
            back.contains("sasl_mechanism: GSSAPI"),
            "expected GSSAPI spelling in:\n{back}"
        );
    }

    #[test]
    fn test_security_config_gssapi_fields_default_to_none() {
        // A pre-GSSAPI config (no kerberos fields) must still parse, with
        // the new fields defaulting to None. Guards backwards-compat for
        // existing deployed configs.
        let yaml = r#"
security_protocol: SASL_SSL
sasl_mechanism: SCRAM-SHA512
sasl_username: alice
sasl_password: hunter2
"#;
        let cfg: SecurityConfig = serde_yaml::from_str(yaml).expect("deserialize legacy config");
        assert_eq!(cfg.sasl_mechanism, Some(SaslMechanism::ScramSha512));
        assert!(cfg.sasl_kerberos_service_name.is_none());
        assert!(cfg.sasl_keytab_path.is_none());
        assert!(cfg.sasl_krb5_config_path.is_none());
    }

    #[test]
    fn test_kafka_config_connection_custom() {
        // Test that custom connection settings are properly parsed
        let yaml = r#"
bootstrap_servers:
  - "localhost:9092"
connection:
  tcp_keepalive: false
  keepalive_time_secs: 30
  keepalive_interval_secs: 10
  tcp_nodelay: false
"#;
        let config: KafkaConfig = serde_yaml::from_str(yaml).unwrap();
        assert!(!config.connection.tcp_keepalive);
        assert_eq!(config.connection.keepalive_time_secs, 30);
        assert_eq!(config.connection.keepalive_interval_secs, 10);
        assert!(!config.connection.tcp_nodelay);
    }

    /// Create a RestoreOptions with valid defaults suitable for testing.
    /// (Rust's derived Default gives 0 for numeric fields, which fails validation.)
    fn valid_restore_options() -> RestoreOptions {
        RestoreOptions {
            max_concurrent_partitions: default_max_concurrent_partitions(),
            produce_batch_size: default_produce_batch_size(),
            produce_acks: default_produce_acks(),
            produce_timeout_ms: default_produce_timeout_ms(),
            checkpoint_interval_secs: default_restore_checkpoint_interval_secs(),
            ..RestoreOptions::default()
        }
    }

    #[test]
    fn test_repartitioning_and_partition_mapping_coexist() {
        // partition_mapping and repartitioning can coexist for different topics:
        // repartitioning takes precedence for its topics, partition_mapping for the rest.
        let mut opts = valid_restore_options();
        opts.partition_mapping.insert(0, 1);
        opts.repartitioning.insert(
            "my-topic".to_string(),
            TopicRepartitioning {
                strategy: RepartitioningStrategy::Murmur2,
                target_partitions: 3,
            },
        );
        assert!(opts.validate().is_ok());
    }

    #[test]
    fn test_repartitioning_invalid_target_partitions() {
        let mut opts = valid_restore_options();
        opts.repartitioning.insert(
            "my-topic".to_string(),
            TopicRepartitioning {
                strategy: RepartitioningStrategy::Murmur2,
                target_partitions: 0,
            },
        );
        assert!(opts.validate().is_err());

        let mut opts2 = valid_restore_options();
        opts2.repartitioning.insert(
            "my-topic".to_string(),
            TopicRepartitioning {
                strategy: RepartitioningStrategy::Murmur2,
                target_partitions: -1,
            },
        );
        assert!(opts2.validate().is_err());
    }

    #[test]
    fn test_repartitioning_yaml_round_trip() {
        let yaml = r#"
repartitioning:
  orders:
    strategy: murmur2
    target_partitions: 3
  events:
    strategy: automatic
    target_partitions: 6
"#;
        let opts: RestoreOptions = serde_yaml::from_str(yaml).unwrap();
        assert_eq!(opts.repartitioning.len(), 2);
        assert_eq!(opts.repartitioning["orders"].target_partitions, 3);
        assert_eq!(
            opts.repartitioning["orders"].strategy,
            RepartitioningStrategy::Murmur2
        );
        assert_eq!(opts.repartitioning["events"].target_partitions, 6);
        assert_eq!(
            opts.repartitioning["events"].strategy,
            RepartitioningStrategy::Automatic
        );

        // Re-serialize and verify round-trip
        let re_serialized = serde_yaml::to_string(&opts).unwrap();
        let re_parsed: RestoreOptions = serde_yaml::from_str(&re_serialized).unwrap();
        assert_eq!(re_parsed.repartitioning.len(), 2);
        assert_eq!(re_parsed.repartitioning["orders"].target_partitions, 3);
    }

    #[test]
    fn test_repartitioning_valid_config() {
        let mut opts = valid_restore_options();
        opts.repartitioning.insert(
            "my-topic".to_string(),
            TopicRepartitioning {
                strategy: RepartitioningStrategy::Murmur2,
                target_partitions: 3,
            },
        );
        assert!(opts.validate().is_ok());
    }
}
